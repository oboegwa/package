## Email
Dejan's IP clearly connects him to all the fraudelant companies involved with the Evolution Gaming directed scam of players.

**IP: 89.212.147.158**

Easy tie of Dejan Jovic's person ("BlueOcean Gaming") Evolution & the scam shells setup like Oryx Gaming and so on, more over also is telling the many laundry companies setup in Slovenia directly connected to this. B-s.si is an example, but there's many more.

Resolves to:
```
mail.juliuslimited.com
AS set propagated by T-2, d.o.o
mail.thtech.eu
AS set propagated by T-2, d.o.
thtech.eu
AS set propagated by T-2, d.o.o.AS set propagated by T-2, d.o.o.
owa.evolutionasia.live
AS set propagated by T-2, d.o.o
mail.troniusgaming.com
AS set propagated by T-2, d.o.o.
mail.evolutionasia.live
AS set propagated by T-2, d.o.o.
mail.moon-casino.com
AS set propagated by T-2, d.o.o
mail.samsvojsvet.com
AS set propagated by T-2, d.o.o.
mail.mirage-enterprise.com
AS set propagated by T-2, d.o.o
mail.mak-op.si
AS set propagated by T-2, d.o.o
AS set propagated by T-2, d.o.
mail.versusodds.com
AS set propagated by T-2, d.o.o.
mail.samsvojsvet.net
AS set propagated by T-2, d.o.o.
mail.svetmontessori.si
AS set propagated by T-2, d.o.o
mail.madisencars.com
AS set propagated by T-2, d.o.o.
autodiscover.mirage-corporation.com
AS set propagated by T-2, d.o.o.
mail.blueoceangaming.com
AS set propagated by T-2, d.o.o
```

Original email:
```
Delivered-To: btchuntas@gmail.com
Received: by 2002:a59:c7ae:0:b0:2d7:5bc:d0a2 with SMTP id c14csp2005935vqu;
        Sun, 31 Jul 2022 13:14:04 -0700 (PDT)
X-Google-Smtp-Source: AA6agR7u5noaGewWzthzUVz2WRM0Y7GxKIO/QwrJ8xYOUxPzeXizl+7vHoxpSRKBxr0Korfc0IFV
X-Received: by 2002:a05:6000:2a8:b0:21d:8c81:7eb0 with SMTP id l8-20020a05600002a800b0021d8c817eb0mr7939723wry.460.1659298444397;
        Sun, 31 Jul 2022 13:14:04 -0700 (PDT)
ARC-Seal: i=1; a=rsa-sha256; t=1659298444; cv=none;
        d=google.com; s=arc-20160816;
        b=Krb/EnDK4lC//S/yihjV+QU/6015cjDI2I4+/132EleyXXdGMIIFbN2uwG3sJ/Oif6
         zWWO+EYO87JKvK1l38PvdypKZBCu1Se2fP4fl4mVCMnogZvbQuwy1hxJKsRU6s8eNhn6
         7eiB2WvFId+R2nzZHISR4Gz+2oSetcr1oz+x4VOKVY+i4NzWrdzdK58RGwh9+C+M+OB1
         UGbq9yhTVv6RphMWSXkDX/6fA3ZvOE0zXh8pD3zpxgp91a8HxoL7pIrkjks/nGx6syeW
         Rm2EjPxXrBQB0R6/nH/rxfVZL8e58QkdvfFaktcFhCqfjyYF7OWfbAuR7ir5Pawk9EUl
         eyMA==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=mime-version:user-agent:content-language:accept-language
         :in-reply-to:references:message-id:date:thread-index:thread-topic
         :subject:to:from;
        bh=DarXIooXq20/U3nSVIInGnAF5SR+NT7AiXcaXOf+llM=;
        b=quoxANbycagRjfQqpnkgGu9dijawJy6zTVaDDjqKwcI8hZIJkWM4gjj9sFefBzcHKc
         lU01jArF79A+xBoMdp6RUorRpyXBma9RLlgXjbUEwhPrBa4RM9CKSJbNbgHeahpbwXJr
         H/KwclIiePOk6VualiH3m82hE1EFvwlXvvHRBW9gh+5ebmUcFeG+mmrdtm+WhAeOVCIe
         d4XrJbqzbGvv1DnmVFFz6bIOacEZ4igYyAyxY7A2in0YQTc4AEWz0EfAjykt9s4oNVWz
         NjZb21u1XbEISpPi9gkT8aYFvn1uJe1fdUi1BmMKAcqojOoGy8Ahb+kShRw4TZKlQfcG
         1S6A==
ARC-Authentication-Results: i=1; mx.google.com;
       spf=pass (google.com: domain of dejan.jovic@blueoceangaming.com designates 89.212.147.158 as permitted sender) smtp.mailfrom=Dejan.Jovic@blueoceangaming.com;
       dmarc=pass (p=NONE sp=NONE dis=NONE) header.from=blueoceangaming.com
Return-Path: <Dejan.Jovic@blueoceangaming.com>
Received: from mail.thtech.eu (mail.thtech.eu. [89.212.147.158])
        by mx.google.com with ESMTPS id a8-20020a05600c348800b003a30f21d0b0si6253227wmq.191.2022.07.31.13.14.04
        for <btchuntas@gmail.com>
        (version=TLS1_2 cipher=ECDHE-ECDSA-AES128-GCM-SHA256 bits=128/128);
        Sun, 31 Jul 2022 13:14:04 -0700 (PDT)
Received-SPF: pass (google.com: domain of dejan.jovic@blueoceangaming.com designates 89.212.147.158 as permitted sender) client-ip=89.212.147.158;
Authentication-Results: mx.google.com;
       spf=pass (google.com: domain of dejan.jovic@blueoceangaming.com designates 89.212.147.158 as permitted sender) smtp.mailfrom=Dejan.Jovic@blueoceangaming.com;
       dmarc=pass (p=NONE sp=NONE dis=NONE) header.from=blueoceangaming.com
From: Dejan Jovic <Dejan.Jovic@blueoceangaming.com>
To: Ryan W <btchuntas@gmail.com>, "david.wainwright@hi2.com" <david.wainwright@hi2.com>
Subject: Re: almost rdy i guess
Thread-Topic: almost rdy i guess
Thread-Index: AQHYpF9t0t/MkTSXYEamsBDquuyR0a2ZDO2A
Date: Sun, 31 Jul 2022 20:14:01 +0000
Message-ID: <52BD3EB6-1E70-4DB1-B2C4-017A9CAC0434@blueoceangaming.com>
References: <CACt7SSXsxUJ42Z8qGx16aCZy3DsLtoy0OCJn5K8y7ESumJ2GEQ@mail.gmail.com>
In-Reply-To: <CACt7SSXsxUJ42Z8qGx16aCZy3DsLtoy0OCJn5K8y7ESumJ2GEQ@mail.gmail.com>
Accept-Language: en-US, sl-SI
Content-Language: en-GB
X-MS-Has-Attach: yes
X-MS-TNEF-Correlator: 
user-agent: Microsoft-MacOutlook/16.63.22070801
x-ms-exchange-messagesentrepresentingtype: 1
x-ms-exchange-transport-fromentityheader: Hosted
x-originating-ip: [192.168.5.13]
x-endpointsecurity-0xde81-ev: v:7.6.1.203, d:out, a:y, w:t, t:18, sv:1659287788, ts:1659298442
Content-Type: multipart/related; boundary="_004_52BD3EB61E704DB1B2C4017A9CAC0434blueoceangamingcom_"; type="multipart/alternative"
MIME-Version: 1.0
```