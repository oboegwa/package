## Todo 
- a lot hehe for productional, though as soon I am able to create stuff again, I will release free casino for any to use (no hidden anything, just like this package)
- this package need a lot of actual testing, mind you i'm far from releasing it (minimum few days) while writing this msg as need to do TON of refactoring as i built this as i went on
- make app toggleable between "proxy_only" and full app, configurable in config
- refactor OPTIMIZATIONS.md much more clearly and categorize between "Simple" (easy toggleable) and "Advanced" optimizations
- add in centrifuge.md
- add in docs md 
- add in "respinning" (aka the wainwright magic touch) feature to skip big bonuses 
- add in pragmatic play completely, also finish bgaming's api version 0 (apiv2 is done it seem), add in either red tiger, netent, isofbet or any relaxgaming
- fiat-currency settings 

## Fun Todo's - todo's that will have little usecase possibly or non-finished but cause I can't bore around all day doing same shit over and over 
- editable jackpot system pragmaticplay games
- replay system pragmaticplay
- simple scan (public) with rulesets to check if a casino is using any frauded games, though probably need to use selenium for this and idk if can soon)
- possibly some simple ggr counting
- create a more configurable & more enjoyable job queue system with somehow custom rules (though cause is also lot of frontend input, i can hopefully in few months start uploading without issue)
- selenium test jobs to "health check" the slotmachine launches (basically you just need to setup a link list & let the selenium client spam spacebar to spin and catch error). Right now there is a simple test done on the 'extra_game_meta' job that is launched when updating the origin demo link, however this is not actual spinning but just looking if page doesn't turn error on launch.
- sports(?) 
- simple casino frontend or representation 
- eh, idk i hope i pick up some new stuff to practice/learn as building slots especially for goal of ratting out casino people is rather boring, you're expected if you want to pick this up more then for a random usecase to seriously look at all code & also to refactor a fuck ton


## Snippets below are for myself to memorize and contain random snippets and stuff I came across copy pasted, it's not meant and will never be organized yet maybe can help people in right direction with making stuff. 


## Evolution Gaming
as done so on evolution I've released before: 

https://github.com/westreels/evv-client/tree/main/websocket

For evolution you will need either access, can use evo-test.com or you can change currencies with the above free sample, it's very straight forward, simply set the currency to a shit one compared to USD$, this way you can levy profit on big currency difference by just changing the currency-fiat symbol like from $ to € (by charging same ggr).
This way all games work, in example difference between the South Korean WON currency:
10 South Korean Won = 0.0076467483 US Dollars

That means if you pay 10% to your provider for a 10$ bet you're really only paying 10% of 0.007$ (while the south korean won is showing as USD$ to the player/operator without any changes), you can charge 10% to your own casino operator. You change the South korean won currency icon to a dollar one, if you charge the same amount or less you will still make insane mark-up.

This probably is most safe way to do without getting interruptions by using public ways, there's evo-test.com you can login using the casino ID and password test123 like:
CASINOID.evo-test.com/api/ ~~ 
Casino ID can be found by launching game on a genuine platform. However like said it's easier in the case of evolution with sidebets and multi-way pots to just do as above, many people do this including sites as BC.Game, Bitstarz.com and others (be it with agreement ofcourse or be it because they are owned by Evolution Gaming themselves for launder).

You can find working example, all you need is to generate JSESSIONID from that can generate EVO_SESSIONID. Just host these 2 repo's and look around:
https://github.com/westreels/evv-client
https://github.com/westreels/evv-api

Both are incredibly easy to setup, though these are not maintained at all, so at own risk. It seems below is a way for pragmaticplay live, including session generation & a 1K balance per session as freebet (though you would need to build accordingly the man in the middle websocket and so on) -- for as long it lasts, probably not long.

## Pragmatic Live
You will need to setup a websocket that send and receive info, so you look like pragmaticplaylive to player and you look like player to pragmaticplay live.
All you do is change betsizing/currencies and implement hard callbacks on balance calls (and lifting off to the casino/operator), probably best is to do a reverse "post route" in-to laravel to get balances and tie it to regular operatorcallbacks you might've extended by now.

This is what I usually do, there is few packages out there ("php-websocket" and many more probably), but i'm scrub at everything so i stick to something i "know sorta" with help of google.

Generate token on demo game that for some reason is in live_casino environment on seperate "space man demo casino". (Most likely its done on purpose tbh lol for matteogang & co):
https://prelive-gs1.pragmaticplaylive.net/api/spacemanDemo &&
After generated token u can use it to enter live games it seems from first glance, like live feed:
https://prelive-static.pragmaticplaylive.net/desktop/speedblackjack/assets/videoplayer/video/pp-livevideo.html?ws_path=wss://ws.pragmaticplaylive.net/BJ24.24&ios_path=https://ios.pragmaticplaylive.net/BJ24.24
you prolly will need to parse the table info from others, though this way seems u will have 1k$ free bet

I find it on lucky just bored and looking what to make in future or idk (spaceman one i was looking) 


An example of websocket for "fiat game" (crash-like game based on exchange price) that posts/relays info direct as an api route in-to local laravel - this was a high freq websocket, so instead of connecting it to all, i could limit it by sending out batched livewire emits:
```json
const WebSocket = require('ws'), axios = require('axios'),
    { r, g, b, w, c, m, y, k } = [['r', 1], ['g', 2], ['b', 4], ['w', 7], ['c', 6], ['m', 5], ['y', 3], ['k', 0]].reduce((cols, col) => ({ ...cols,  [col[0]]: f => `\x1b[3${col[1]}m${f}\x1b[0m` }), {});

let socket = null, connectionInterval = null, latestData = null;

const connect = () => {
    if(socket) socket.close();
    if(connectionInterval) clearInterval(connectionInterval);

    socket = new WebSocket('wss://ws-feed.pro.coinbase.com');

    socket.addEventListener('open', function (event) {
        socket.send(JSON.stringify({
            type: "subscribe",
            channels: [
                {
                    name: "ticker",
                    product_ids: [
                        "BTC-USD",
                        "ETH-USD"
                    ]
                }
            ]
        }));
    });

    socket.addEventListener('message', function (message) {
        const data = JSON.parse(message.data);

        latestData = data;

        if (data.type === 'ticker') {
            console.log(r(data.product_id), w(JSON.stringify(data)));

            axios.post('http://localhost/api/node/pushBullData', {
                data: {
                    [data.product_id]: data
                }
            }).catch((error) => console.error('Failed to push data!'));
        } else console.log(c('WS Message'), message.data);
    });

    let latestDataTested = null;
    connectionInterval = setInterval(() => {
        if(latestData && latestDataTested && latestData === latestDataTested) connect();
        latestDataTested = latestData;
    }, 10000);
};

connect();
```

&& the route within laravel (make sure to make this only accessible from localhost):

```
Route::prefix('node')->group(function () {
    Route::post('pushBullData', [ExternalController::class, 'pushBullData']);
});
```


## Request netent

```json

rs.i0.r.i1.pos=29&gameServerVersion=1.0.0&g4mode=false&game.win.coins=0&playercurrency=%26%23x20AC%3B&playercurrencyiso=EUR&historybutton=false&
rs.i0.r.i1.hold=false&current.rs.i0=basic&rs.i0.r.i4.hold=false&next.rs=basic&gamestate.history=basic&playforfun=true&
jackpotcurrencyiso=EUR&clientaction=spin&rs.i0.r.i1.syms=SYM5%2CSYM12%2CSYM9&rs.i0.r.i2.hold=false&rs.i0.r.i4.syms=SYM6%2CSYM7%2CSYM4&game.win.cents=0&rs.i0.r.i2.pos=27&rs.i0.id=basic&totalwin.coins=0&credit=499910&totalwin.cents=0&gamestate.current=basic&gameover=true&rs.i0.r.i0.hold=false&jackpotcurrency=%26%23x20AC%3B&multiplier=1&rs.i0.r.i3.pos=69&rs.i0.r.i4.pos=41&
rs.i0.r.i0.syms=SYM9%2CSYM12%2CSYM6&rs.i0.r.i3.syms=SYM7%2CSYM8%2CSYM9&isJackpotWin=false&gamestate.stack=basic&nextaction=spin&rs.i0.r.i0.pos=40&
wavecount=1&gamesoundurl=https%3A%2F%2Fstatic.casinomodule.com%2F&rs.i0.r.i2.syms=SYM9%2CSYM5%2CSYM3&rs.i0.r.i3.hold=false&

game.win.amount=0&cjpUrl=https%3A%2F%2Fcjp-dev.casinomodule.com
rs.i0.r.i1.pos=36&gameServerVersion=1.0.0&g4mode=false&game.win.coins=0&playercurrency=%26%23x20AC%3B&playercurrencyiso=EUR&historybutton=false&rs.i0.r.i1.hold=false&current.rs.i0=basic&rs.i0.r.i4.hold=false&next.rs=basic&gamestate.history=basic&playforfun=true&jackpotcurrencyiso=EUR&clientaction=spin&rs.i0.r.i1.syms=SYM12%2CSYM7%2CSYM1&rs.i0.r.i2.hold=false&rs.i0.r.i4.syms=SYM0%2CSYM8%2CSYM4&game.win.cents=0&rs.i0.r.i2.pos=75&rs.i0.id=basic&totalwin.coins=0&credit=499970&totalwin.cents=0&gamestate.current=basic&gameover=true&rs.i0.r.i0.hold=false&jackpotcurrency=%26%23x20AC%3B&multiplier=1&rs.i0.r.i3.pos=7&rs.i0.r.i4.pos=59&rs.i0.r.i0.syms=SYM12%2CSYM6%2CSYM8&rs.i0.r.i3.syms=SYM9%2CSYM4%2CSYM10&isJackpotWin=false&gamestate.stack=basic&nextaction=spin&rs.i0.r.i0.pos=12&wavecount=1&gamesoundurl=https%3A%2F%2Fstatic.casinomodule.com%2F&rs.i0.r.i2.syms=SYM4%2CSYM9%2CSYM10&rs.i0.r.i3.hold=false&game.win.amount=0&cjpUrl=https%3A%2F%2Fcjp-dev.casinomodule.com

https://netent-game.casinomodule.com/servlet/CasinoGameServlet;jsession=DEMO-702574331-EUR?action=spin&sessid=DEMO-702574331-EUR&gameId=deadoralive2_not_mobile&wantsreels=true&
wantsfreerounds=true&freeroundmode=false&bet.betlevel=1&bet.denomination=10&bet.betlines=0-8&no-cache=1e796ff1-9c0e-45b0-851c-3a9b6ae76188&bettingmode=coins

https://netent-static.casinomodule.com/games/dead-or-alive-2-client/game/dead-or-alive-2-client.xhtml?launchType=iframe&iframeSandbox=allow-scripts allow-popups allow-popups-to-escape-sandbox allow-top-navigation allow-top-navigation-by-user-activation allow-same-origin allow-forms allow-pointer-lock&applicationType=browser&gameId=deadoralive2_not_mobile&showHomeButton=false&gameLocation=games/dead-or-alive-2-client/&preBuiltGameRulesSupported=true&server=http://tolars.net/api/respins.io/games/netent?dividerTag=/&lang=en&sessId=DEMO-4190492579-EUR&operatorId=netent&logsId=19766ded-ea15-4c06-8b65-81f85440baf6&loadStarted=1660031775497&giOperatorConfig={"staticServer":"https://netent-static.casinomodule.com/","targetElement":"netentgame","launchType":"iframe","iframeSandbox":"allow-scripts allow-popups allow-popups-to-escape-sandbox allow-top-navigation allow-top-navigation-by-user-activation allow-same-origin allow-forms allow-pointer-lock","applicationType":"browser","gameId":"deadoralive2_not_mobile","showHomeButton":true,"gameLocation":"games/dead-or-alive-2-client/","preBuiltGameRulesSupported":true,"server":"http://tolars.net/api/respins.io/games/netent?dividerTag","lang":"en","sessId":"DEMO-4190492579-EUR","operatorId":"netent"}&casinourl=&testGroup=B

```

curl 'https://netent-game.casinomodule.com/servlet/CasinoGameServlet;jsession=DEMO-5430562958-EUR?action=spin&sessid=DEMO-5430562958-EUR&gameId=starburst_not_mobile&wantsreels=true&wantsfreerounds=true&freeroundmode=false&bet.betlevel=1&bet.denomination=20&bet.betlines=0-9&no-cache=77ac2f4a-5e5f-45d8-88b6-8dcfa1a5efd8&bettingmode=coins' \
  -H 'Accept: */*' \
  -H 'Accept-Language: en-ZA,en;q=0.9' \
  -H 'Cache-Control: no-cache' \
  -H 'Connection: keep-alive' \
  -H 'Origin: https://netent-static.casinomodule.com' \
  -H 'Pragma: no-cache' \
  -H 'Referer: https://netent-static.casinomodule.com/' \
  -H 'Sec-Fetch-Dest: empty' \
  -H 'Sec-Fetch-Mode: cors' \
  -H 'Sec-Fetch-Site: same-site' \
  -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36' \
  -H 'sec-ch-ua: ".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"' \
  -H 'sec-ch-ua-mobile: ?0' \
  -H 'sec-ch-ua-platform: "Linux"' \
  --compressed

https://tolars.net/api/respins.io/games/netent?dividerTagservlet/CasinoGameServlet;jsession=DEMO-4190492579-EUR?action=spin&sessid=DEMO-4190492579-EUR&gameId=deadoralive2_not_mobile&wantsreels=true&wantsfreerounds=true&freeroundmode=false&bet.betlevel=1&bet.denomination=10&bet.betlines=0-8&no-cache=dce23ff6-51b5-44c1-a88c-72f057aba6c0&bettingmode=coins

## Game adjustment (by netent/evolution illegal gambling vendor)

```json

/*
 * 1.26.0
 * 
 *
 * Copyright, NetEnt AB (publ)
 * Website: https://www.netent.com/
*/

var netent_netentextend=function(){var n;return n=function(n,e,t){var o=this;e=e||{},o.hide=function(){n.style.visibility="hidden"},o.show=function(){n.style.visibility="visible"},o.resize=function(t,o){var i;if(void 0===t||void 0===o)throw new netent_error_handling.GiError(1,"netent_netentextend.main","resize","resize");i=netent_tools.resize(e.defaultWidth,e.defaultHeight,t,o,e.enforceRatio),n.style.width=i.width,n.style.height=i.height},o.addEventListener=function(n,e){void 0===t[n]&&(t[n]=[],o.sendSubscriptionLog(n)),t[n].push(e)},o.removeEventListener=function(n,e){var o,i=t[n];void 0!==i&&(o=i.indexOf(e),o>=0&&i.splice(o,1))}},n.prototype.get=function(n,e){},n.prototype.set=function(n,e,t){},n.prototype.call=function(n,e,t){},n.prototype.post=function(n,e,t,o,i){},n.prototype.sendSubscriptionLog=function(n){},{Base:n}}(),netent_nee_html_embed=function(){var n=function(n,e){var t,o,i,r,a,s,c,g,l,u,f,d,h=0,p={},m="subscriptionLog",_=!1,v=[],y=function(){};t={},f=function(n){var e=Array.prototype.slice.call(arguments,1);n.postMessage.apply(n,e)},netent_netentextend.Base.call(this,n,e,p),s=function(n){_&&console.warn("sendSubscriptionLog something went wrong: ",n)},a=function(n){_&&console.log("sendSubscriptionLog success: ",n)},r=function(n){var e,t=Array.prototype.slice.call(arguments,1),o=p[n];if(void 0!==o)for(e=0;e<o.length;e++)o[e].apply(null,t)},g=function(n){var e=t[n];return e?(clearTimeout(e.timeout),delete t[n]):e={success:y,error:y},e},l=function(n){var e=g(n),t=e.success,o=Array.prototype.slice.call(arguments,1);t.apply(null,o)},u=function(n,e,t){var o=g(n),i=o.error;i(new netent_error_handling.GiError(e,"netent_nee_html_embed",t||""))},i=function(n){var e,t;netent_validation.validateMessage(n)&&(e=n.data[0],t=n.data.slice(1),"success"===e?l.apply(null,t):"error"===e?u.apply(null,t):"event"===e&&(d=!0,c(),r.apply(null,t)))},o=function(e,o,i,r,a){h+=1,t[h]={success:r||y,error:a,timeout:setTimeout(function(n){return function(){u(n,11)}}(h),1e3)},f(n.contentWindow,[e,h,o].concat(i),"*")},c=function(){v.length&&(v.forEach(function(n){o(m,n,[],a.bind(null,n),s)}),v.length=0)},this.get=function(n,e,t){var i=this,r=netent_error_handling.handler(t);if("function"!=typeof e&&"function"!=typeof t)return new Promise(function(e,t){i.get(n,e,t)});try{netent_netentextend.Base.prototype.get.call(this,n,e,r),o("get",n,[],e,r)}catch(a){r(a)}},this.sendSubscriptionLog=function(n){try{d?o(m,n,[],a.bind(null,n),s):v.push(n)}catch(e){s(e)}},this.set=function(n,e,t,i){var r=this,a=netent_error_handling.handler(i);if("function"!=typeof t&&"function"!=typeof i)return new Promise(function(t,o){r.set(n,e,t,o)});try{netent_netentextend.Base.prototype.set.call(this,n,e,t,a),o("set",n,[e],t,a)}catch(s){a(s)}},this.call=function(n,e,t,i){var r=this,a=netent_error_handling.handler(i);if("function"!=typeof t&&"function"!=typeof i)return new Promise(function(t,o){r.call(n,e,t,o)});try{o("call",n,e,t,a)}catch(s){a(s)}},window.removeEventListener("message",window.neeOnMessage),window.neeOnMessage=i,window.addEventListener("message",i)};return netent_netentextend.Html=n,{Html:n}}(),netent_config_handling=function(){var n={targetElement:"neGameClient"},e={gameId:"string",gameName:"string",sessionId:"string",staticServer:"string",gameServerURL:"string",giLocation:"string",width:"string",height:"string",enforceRatio:"boolean",targetElement:"string",walletMode:"string",currency:"string",operatorId:"string",liveCasinoParams:{casinoId:"string"}},t=[{from:"gameServer",to:"gameServerURL"},{from:"historyUrl",to:"historyURL"},{from:"pluginUrl",to:"pluginURL"},{from:"lobbyUrl",to:"lobbyURL"},{from:"staticServerURL",to:"staticServer"},{from:"helpUrl",to:"helpURL"}],o=function(n){t.forEach(function(e){n.hasOwnProperty(e.from)&&!n.hasOwnProperty(e.to)&&(n[e.to]=n[e.from]),delete n[e.from]}),Object.keys(n).forEach(function(e){"object"==typeof n[e]&&Object.keys(n[e]).length>0&&o(n[e])})},i=function(n){var e;for(e in n)"object"==typeof n[e]&&null!==n[e]?(n[e]=i(n[e]),0===Object.keys(n[e]).length&&delete n[e]):(null===n[e]||"undefined"==typeof n[e]||"string"==typeof n[e]&&!n[e])&&"gameRulesURL"!==e&&delete n[e];return n},r=function(n,e){i(n),o(n),n.giLocation&&(n.giLocation=n.giLocation.replace(/\/?$/,"/")),n.staticServer&&(n.staticServer=n.staticServer.replace(/\/?$/,"/")),n.gameServerURL&&(n.gameServerURL=n.gameServerURL.replace(/\/?$/,"/")),e(n)};return{essentialParameters:e,handleConfig:r,defaultValues:n,filterRedundantParameters:i}}(),netent_error_handling=function(){var n=function(n,e,t,o){var i=this;return"number"!=typeof n?(i.code=0,i.error=n,i.message=netent_errors[0].replace("<error>",n),i.causedBy=t,void(i.origin=e)):(i.code=n,i.message=netent_errors[n],i.origin=e,i.causedBy=t,void(o&&(Object.getOwnPropertyNames(o).forEach(function(n){i.message?i.message=i.message.replace("<"+n+">",o[n]):i.message=o.error},i),i.variables=o)))},e=function(e){return function(t,o,i,r){var a;e&&(a=t instanceof n?t:t instanceof TypeError||t instanceof ReferenceError?new n(21,o,t):new n(t,o,i,r),netent_logging_handling.log(a),e(a))}};return{GiError:n,handler:e}}(),netent_errors=function(){return{0:"Unknown error: '<error>'",1:"Value for '<key>' is invalid, expects to be <type>",4:"Could not retrieve game configuration",9:"This functionality is not supported by this game",10:"Wrong number of arguments",11:"No answer from game",13:"SWFObject could not launch game",14:"Could not load SWFObject",16:"Target element '<value>' does not exist",17:"No value provided for essential parameter '<parameter>'",18:"Unable to launch HTML game",21:"This browser is not supported",23:"Could not open '<url>'.",24:"Could not init module '<module>'.",25:"Could not load module '<module>'.",26:"Height or width in percentage is not supported when enforceRatio=true."}}(),netent_gi_core=function(){var n,e=function(n,e,t,o){t=t||function(){},o=netent_error_handling.handler(o);try{netent_config_handling.handleConfig(e,function(){netent_module_handling.addAndLoadWithConfig(n,e,t,o)})}catch(i){o(i)}},t=function(n,o,i){var r,a,s;if("function"!=typeof o&&"function"!=typeof i)return new Promise(function(e,o){t(n,e,o)});if(netent_logging_handling.queue(),a=function(n){var t=netent_tools.combine({},n);e("launch",n,function(e){try{e&&e.addEventListener&&!netent_logging_handling.listenersAdded&&(netent_logging_handling.listenersAdded=!0,e.addEventListener("gameReady",function(){netent_logging_handling.log("game_ready")}),e.addEventListener("gameError",function(n){netent_logging_handling.log({gameError:n})}))}catch(i){console.warn("e",i)}netent_logging_handling.initLogging(n,t),o(e)},function(e){i(e),netent_logging_handling.initialized||netent_logging_handling.initLogging(n,t)})},s=n.staticServer||n.staticServerURL||"","string"!=typeof s)throw new Error("Cannot launch the game with the current configuration.");r=netent_tools.concat(s,"/config/services.json"),netent_gi_core.getDynamicHostname(r,s,function(e){var t=netent_tools.combine(n,{staticServer:e});a(t)})},o=function(n,e,t){netent_json_handling.getJson(n,function(n){t(n?n.clienthost?n.clienthost.trim():e:e)},function(n){t(e)})},i=function(n,t,o){if("function"!=typeof t&&"function"!=typeof o)return new Promise(function(e,t){i(n,e,t)});const r=n.staticServer||n.staticServerURL||"";if("string"!=typeof r)throw new Error("Cannot launch the game with the current configuration.");const a=netent_tools.concat(r,"/config/services.json");netent_gi_core.getDynamicHostname(a,r,function(i){const r=netent_tools.combine(n,{staticServer:i}),a=netent_tools.combine({},r);e("getgamerules",a,t,o)})},r=function(e){var t,o;return n?n:(e||(e=window.parent),t={contentWindow:e},o=new netent_netentextend.Html(t,{netentExtendSupported:!0}),n={get:o.get.bind(o),set:o.set.bind(o),call:o.call.bind(o),addEventListener:o.addEventListener.bind(o),removeEventListener:o.removeEventListener.bind(o)})},a=function(n,t,o){return"function"!=typeof t&&"function"!=typeof o?new Promise(function(e,t){a(n,e,t)}):void e("lcapi",n,t,o)};return{launch:t,getDynamicHostname:o,getGameRules:i,getOpenTables:a,plugin:r}}(),netent_json_handling=function(){var n=function(n,e,t,o,i){var r=new XMLHttpRequest;r.open(n,e,!0),r.onreadystatechange=function(){4===r.readyState&&(200===r.status?t(r.responseText):o(r.status>0&&200!==r.status?r.responseText:new netent_error_handling.GiError(23,"netent_gi_core",r,{url:e})))},"GET"===n?r.send():(r.setRequestHeader("Content-Type","application/json;charset=utf-8"),r.send(JSON.stringify(i)))},e=function(e,t,o,i,r){n(e,t,function(n){try{o(JSON.parse(n))}catch(e){i(new netent_error_handling.GiError(23,"netent_gi_core",{url:t}))}},i,r)},t=function(n,t,o,i){e("POST",n,o,i,t)},o=function(){var n={};return function(t,o,i,r){!r&&n[t]?o(n[t]):e("GET",t,function(e){n[t]=e,o(n[t])},i)}}();return{getJson:o,postJson:t}}(),netent_language_handling=function(){var n="en",e={ar:"ar-KW",he:"iw","pt-BR":"br","pt-PT":"pt","zh-Hans":"cn","zh-Hant":"zh-TW"},t={"fr-CA":"fr","es-US":"es","zh-TW":"cn","nl-BE":"nl"},o=function(n,e){var t=n.staticServer+e+"langlib/";return function(n){var e,o;o=t+n+"/"+n+".json";try{return e=new XMLHttpRequest,e.open("GET",o,!1),e.send(),200===e.status}catch(i){return!1}}},i=function(n){return n in t},r=function(n){return n in e},a=function(n){var e;return i(n)?(e=t[n],[e]):[]},s=function(n){if(r(n)){const t=e[n];return[n,t].concat(a(t))}return[n].concat(a(n))},c=function(e,t){var i,r,a,c,g;if(i=e.language,r=o(e,t),!i)return n;for(g=s(i),c=0;c<g.length;c++)if(a=g[c],r(a))return a;return i};return{getLanguage:c,getFallbackList:s}}(),initConfig={url:"https://gcs-prod.casinomodule.com/gcs/init",clientname:"game-inclusion",clientver:"1.26.0"},netent_logging_handling=function(){var n=new Date,e=function(){var n=[];return function(e){return e&&n.push({event:e,timestamp:new Date}),n}}(),t=function(){e().length=0,netent_logging_handling.log=function(){},netent_logging_handling.initialized=!0},o=function(){netent_logging_handling.log=e,netent_logging_handling.initialized=!1},i=function(n){var e,t;if(n.casinoBrand)return n.casinoBrand;try{return e=new RegExp("^(?:\\w*:\\/\\/)?([a-zA-Z0-9-]+?)(?:-static|-scs|\\.)\\S+$"),t=e.exec(n.staticServer)[1],t||"unbranded"}catch(o){return""}},r=function(n,e,t){var o={clientname:initConfig.clientname,clientver:initConfig.clientver,casinoid:i(n),gameid:n.gameId||""},r=n&&n.loggingURL||initConfig.url;netent_json_handling.postJson(r,o,function(n){n.initRequest=o,e(n)},t)},a=function(n){return netent_tools.getBooleanValue(n.enabled,!1)&&n.hasOwnProperty("configuration")},s=function(i,s,c){var g=function(n,e,t,o){console.warn(n,e,t,o),"function"==typeof c&&c()},l=function(n){var t;if(n){for(;e().length;)t=e().shift(),n(t.event,t.timestamp);netent_logging_handling.log=n,"function"==typeof c&&c()}};return netent_tools.getBooleanValue(i.disableLogging,!1)?(t(),void("function"==typeof c&&c())):(o(),netent_logging_handling.initialized=!0,void r(i,function(e){a(e)?(e.gi_started_time=n,e.operatorConfig=i,e.launchConfig=s,e.staticServer=i.staticServer,s&&s.giLocation&&(e.giLocation=s.giLocation),netent_logging_handling.statisticEndpointURL=e.configuration.endpoint,netent_module_handling.addAndLoadWithConfig("logging",e,l,g)):(t(),"function"==typeof c&&c())},g))};return{initLogging:s,log:e,queue:o,initialized:!1,listenersAdded:!1}}(),netent_module_handling=function(){var n={},e="netent_module_handling",t=function(e){return n[e].loaded},o=function(e,t){return n[e].essentialParameters=window[e].essentialParameters,Boolean(netent_validation.validateEssentialParameters(n[e].essentialParameters,n[e].config,t))},i=function(t,i,r){var a,s;try{o(t,r)&&(a=window[t].init,s=n[t],a(s.config,i,r))}catch(c){r(24,e,c,{module:t})}},r=function(e,t){n[e].loaded=t},a=function(e,t){var o=n[e].config.giLocation||n[e].config.staticServer+"gameinclusion/library/",i="modules"+(t||"")+"/"+e.split("netent_")[1]+"/main.js",r="";return o=decodeURIComponent(o),o.split("?")[1]&&(r="?"+o.split("?")[1]),o.split("?")[0]+i+r},s=function(n,o,s,c){t(n)?i(n,s,c):netent_tools.loadScript(a(n,o),function(){r(n,!0),i(n,s,c)},function(t){c(25,e,t,{module:n})})},c=function(e,t){n[e]||(n[e]={},r(e,!1)),n[e].config=t},g=function(n,e,t,o,i){n="netent_"+n,c(n,e),s(n,i,t,o)};return{addAndLoadWithConfig:g}}(),netent_tools=function(){var n=function(e,t){var o,i,r,a={};for(o in e)if(e.hasOwnProperty(o))if("object"==typeof e[o]){i=n(e[o],t);for(r in i)i.hasOwnProperty(r)&&(a[t?o+"."+r:r]=i[r])}else a[o]=e[o];return a},e=function(){var n=function(n,t){var o,i=JSON.parse(JSON.stringify(n));for(o in t)"object"==typeof t[o]&&"[object Array]"!==Object.prototype.toString.call(t[o])?(n[o]=n[o]||{},i[o]=e(n[o],t[o])):i[o]=t[o];return i};return function(){var e,t,o=arguments[0];for(t=1;t<arguments.length;t++)e=arguments[t],void 0!==e&&(o=n(o,e));return o}}(),t=function(n,e,t,o){var i=document.createElement("script");i.setAttribute("src",n),i.onload=e,i.onerror=t,o&&i.setAttribute("id",o),document.getElementsByTagName("head")[0].appendChild(i)},o=function(n){return"string"==typeof n?/^\d+\.?\d*$/.test(n):"number"==typeof n},i=function(n){return/^(px|em|pt|in|cm|mm|ex|pc|rem|vw|vh|%)$/.test(n)},r=function(n,e,t,o){var r=i(e)?e:"px",a=i(o)?o:"px";return t>=n?i(e)?e:a:i(o)?o:r},a=function(n,e,t,i,a){var s=/^(\d+\.?\d*)(\D*)$/,c=s.exec(n),g=s.exec(e),l=parseInt(c[1],10),u=parseInt(g[1],10),f=s.exec(t),d=s.exec(i),h=parseInt(f[1],10),p=parseInt(d[1],10),m=l/u,_=u/l,v={},y=r(h,f[2],p,d[2]);if(!a)return o(t)&&(t+=y),o(i)&&(i+=y),{width:t||"",height:i||""};if("%"===y)throw new netent_error_handling.GiError(26,"common.embed","% as unit");return o(h)||o(p)?!o(p)||p>=h*_?(v.width=h,v.height=h*_):(v.height=p,v.width=p*m):(v.width=l,v.height=u),v.width=Math.round(parseInt(v.width,10))+y,v.height=Math.round(parseInt(v.height,10))+y,v},s=function(n){var e;for(e in n)!n.hasOwnProperty(e)||null!==n[e]&&void 0!==n[e]||delete n[e]},c=function(n,e){var t=e;return"boolean"==typeof n?n:n?(n=n.toLowerCase(),"true"===n?t=!0:"false"===n&&(t=!1),t):t},g=function(n,e,t){var o;return netent_logging_handling.statisticEndpointURL?(t="undefined"!=typeof t?t:!0,o=t?encodeURIComponent(JSON.stringify(netent_logging.giOperatorConfig)):JSON.stringify(netent_logging.giOperatorConfig),"object"==typeof n&&(n.statisticEndpointURL=netent_logging_handling.statisticEndpointURL,n.logsId=netent_logging.logsId,n.loadStarted=netent_logging.game_load_started_time,n.giOperatorConfig=o,n.casinourl=netent_logging.casinourl,n.loadSeqNo=netent_logging.loadSeqNo,e&&(n.redirect="true")),"string"==typeof n&&(n+=-1===n.indexOf("?")?"?":"&",n+="statisticEndpointURL="+netent_logging_handling.statisticEndpointURL,n+="&logsId="+netent_logging.logsId,n+="&loadStarted="+netent_logging.game_load_started_time,n+="&giOperatorConfig="+o,n+="&casinourl="+netent_logging.casinourl,n+="&loadSeqNo="+netent_logging.loadSeqNo,e&&(n+="&redirect=true")),n):n},l=function(n){var e,t="DEMO-";for(e=0;13>e;e++)t+=Math.floor(10*Math.random());return t+="-"+(n||"EUR")},u=function(n,e){var t,o=[{from:"gameServerURL",to:"server"},{from:"language",to:"lang"},{from:"sessionId",to:e},{from:"casinoBrand",to:"operatorId"}];return n.hasOwnProperty("mobileParams")&&(t=n.mobileParams,Object.keys(t).forEach(function(e){t.hasOwnProperty(e)&&!n.hasOwnProperty(e)&&(n[e]=t[e])})),delete n.mobileParams,o.forEach(function(e){n.hasOwnProperty(e.from)&&(n[e.to]=n[e.from]),delete n[e.from]}),n},f=function(n,e){var t,o;return n=n.lastIndexOf("/")===n.length-1?n.substr(0,n.length-1):n,e=0===e.indexOf("/")?e.substr(1):e,t=""===n&&""===e,o=t?"":String(n+"/"+e)};return{flatten:n,combine:e,loadScript:t,removeMissingProperties:s,resize:a,getBooleanValue:c,addLoggingData:g,createDemoSessionID:l,transformConfig:u,concat:f}}(),netent_validation=function(){var n={string:/.*$/,"boolean":/^(true|false|TRUE|FALSE|True|False)$/},e=function(e,t,o){return void 0===t||void 0===o||n[o].test(t)?0:{key:e,type:o}},t=function(n){var t,o,i,r,a=netent_config_handling.essentialParameters,s=[];for(t in a)if(a.hasOwnProperty(t))if(o=a[t],"string"==typeof o)s.push(e(t,n[t],o));else for(i in o)o.hasOwnProperty(i)&&(r=n[t]?n[t][i]:void 0,s.push(e(t+"."+i,r,o[i])));return s.filter(Boolean)},o=function(n,e){var t;if(-1!==n.indexOf(".")){if(t=n.split(".",2),!e[t[0]]||!e[t[0]][t[1]])return!1}else if(!e[n])return!1;return!0},i=function(n,e,t){var i,r,a,s,c,g,l=0,u="||";if(n)for(i=0;i<n.length;i++)if(a=n[i],-1!==a.indexOf(u)){for(s=a.split(u),c=!1,r=0;r<s.length;r++)if(o(s[r],e)){c=!0;break}c||(l++,t(17,"netent_config_handling",a,{parameter:a}))}else o(a,e)||(l++,t(17,"netent_config_handling",a,{parameter:a}));return g=netent_validation.verifyConfigValueTypes(e),0!==g.length&&g.forEach(function(n){l++,t(1,"netent_config_handling","validate parameters",n)}),0===l},r=function(n){return n&&"[object Array]"===Object.prototype.toString.call(n.data)&&n.data.length>0};return{validateEssentialParameters:i,verifyConfigValueTypes:t,validateMessage:r}}();window.netent={launch:netent_gi_core.launch,getGameRulesUrl:netent_gi_core.getGameRules,getGameRulesURL:netent_gi_core.getGameRules,getGameRules:netent_gi_core.getGameRules,getOpenTables:netent_gi_core.getOpenTables},Object.defineProperty(window.netent,"plugin",{get:netent_gi_core.plugin});

```

```json
/*
Will handle game loading and sizing
*/
var Game = {
	config: {},
	active_size: "",
	target_element: "",
	sess_id: Math.floor(Math.random() * 10000000000) + 1,
	mobile_breakpoint: 414,
	game_handle: null,

	init: function(config){
		//Set our main config
		this.config = config;

		//Determine the window size, select a config and start game.
		var height = window.innerHeight;
		var width = window.innerWidth;
		console.log("Detected window size: "+width+" x "+height);

		//If on mobile, select mobile config.
		if(width  <= this.mobile_breakpoint){
			this.active_size = "mobile";
			this.target_element = "netentGameMobile";
		}
		else{
			this.active_size = "desktop";
			this.target_element = "netentgame";
		}

		console.log(this.active_size);
		$(window).resize(this.handleResize.bind(this));
		this.startGame();
	},

	handleResize: function(){
		var window_height = window.innerHeight;
		var window_width = window.innerWidth;
		var detected_size;

		if(window_width <= this.mobile_breakpoint){
			detected_size = "mobile"
		}
		else{
			detected_size = "desktop"
		}

		if(detected_size !== this.active_size){
			this.active_size = detected_size;			
			$('#'+this.target_element).parent().html('<div id="'+this.target_element+'"></div>'); //Remove replace old iframe with blank div (for reuse later)
			this.target_element = (detected_size === "mobile")? "netentGameMobile" : "netentgame";
			this.game_handle = null;			
			this.startGame();
			console.log("Screen size change to "+this.active_size+". Reloading game");
		}
		else if(this.game_handle){
			var width = $("#"+this.target_element).parent().outerWidth();
			var height = $("#"+this.target_element).parent().outerHeight();			
			this.game_handle.resize(width, height);
			console.log("Resizing to "+width+" x "+height);		
		}
	},

	startGame: function(){
		var size_config = this.config.sizes[this.active_size];

		if(typeof size_config === "undefined"){
			//Couldn't find config for this size, exit
			return;
		}

		var config = {
			staticServer: "https://"+this.config.casino_id+"-static.casinomodule.com",
			gameServer: "https://"+this.config.casino_game+".casinomodule.com",
			sessionId: "DEMO-"+this.sess_id+"-"+this.config.session_currency,  //<?php echo $_SESSION['_set_current_locale']['currency']; ?>",
			targetElement: this.target_element,
			walletMode : "basicwallet",
			language: this.config.session_language, //'<?php echo $_SESSION['_set_current_locale']['language']; ?>',
			launchType: 'iframe',
			iframeSandbox: 'allow-scripts allow-popups allow-popups-to-escape-sandbox allow-top-navigation allow-top-navigation-by-user-activation allow-same-origin allow-forms allow-pointer-lock',
			applicationType: 'browser',
			gameId: size_config.variant,
			casinoBrand: "netent"
		};

		console.log("Launching "+this.active_size);
		netent.launch(config, this.gameLoadSuccess.bind(this), this.gameLoadError.bind(this));
	},

	gameLoadSuccess: function(netEntExtend){
		this.game_handle = netEntExtend;

		if(typeof gameEventHandlerExtend !== "undefined"){
			var events = [ 
				"gameReady", "spinStarted", "spinProgress", "spinEnded", "gameRoundStarted", 
				"gameRoundEnded", "volumeChange", "audioToggle", "balanceChanged", "gameError", 
				"bonusGameStarted", "bonusGameEnded", "freeSpinStarted", "freeSpinEnded", 
				"autoplayStarted", "autoplayEnded", "autoplayNextRound"
			];

			for(var j=0;j<events.length-1;j++)
			{
				//console.log("Setting up handler for " + events[j]);
				var func = new Function("name", "var b = new Array('" + events[j] + "',new Array(arguments[0])); gameEventHandlerExtend(b);");
				netEntExtend.addEventListener(events[j], func );
			}
		}

		var width = $("#"+this.target_element).parent().outerWidth();
		var height = $("#"+this.target_element).parent().outerHeight();
		console.log("Game loaded. Detected size: "+width+" x "+height);
		netEntExtend.resize(width, height);
	},

	gameLoadError: function(e){
		console.log(e)
		//show flash error for visitor
		if(e.code == 13) {
			$("#netentgame span").html("Please allow Flash content in your web browser to start the game.");
		}

	}
};



```

## Betgames create game
https://webiframe.betgames.tv/#/auth?apiUrl=APIURL&partnerCode=viewbet&partnerToken=0fcfd8a4-79b4-4efc-a6a3-9f1b476a7346&language=en&timezone=7&homeUrl=http://redirect.com

## PPLive (fake)
https://client.pragmaticplaylive.net/desktop/?tabletype=all&casino_id=ppcdg00000001558&web_server=https://games.pragmaticplaylive.net&config_url=/cgibin/appconfig/xml/configs/urls.xml&JSESSIONID=ECdk2AvCr_8E9FZO2FQTSqxpDDIka9rIumUzHCmNkrI1h1-2nXRU!415565709&socket_server=wss://games.pragmaticplaylive.net/game&token=ECdk2AvCr_8E9FZO2FQTSqxpDDIka9rIumUzHCmNkrI1h1-2nXRU!415565709&stats_collector_uuid=f167e6b6-3c30-4ee1-8e4f-220ed9cde0ef&actual_web_server=https://games.pragmaticplaylive.net&socket_port=443&uiAddress=https://client.pragmaticplaylive.net/desktop/&uiversion=1.15.2&gametype=all&game_mode=html5_desktop&lang=en&swf_lobby_path=/member/games/lobby.swf&lobbyGameSymbol=null&

## PPGames (fake)
https://viewbet.live/play?game_code=pragmaticslot&game_list_id=vs20cleocatra&game_list_image=https:%2F%2Fstatus-res.askmebet.com%2Fpragmatic%2Fvs20cleocatra.webp&game_list_name=Cleocatra
https://askmebet-sg1.ppgames.net/gs2c/html5Game.do?jackpotid=0&gname=Cleocatra&extGame=1&ext=0&cb_target=exist_tab&symbol=vs20cleocatra&jurisdictionID=99&lobbyUrl=http%3A%2F%2Fredirect.com&minilobby=false&mgckey=AUTHTOKEN@936277fe9a21d016e38c77dbdf0eba9ed182994f003dc216a6e8d7276d5141a7~stylename@amb_viewbet~SESSION@843ba04d-6fda-4a6a-9c39-d33b879dd1a6~SN@e336f38d&tabName=

## SA Gaming
https://al5.sa-api5.com/h5web/index.html?username=11ppg2de5c@al5&token=8FC9E06251DFA10FB996440769269895&lang=en&lobby=a1424&returnurl=http%3a%2f%2fredirect.com&net=0&h5web=True&ui=1&options=hidemultiplayer%3d1%2chideslot%3d1%2cdefaulttable%3d1&ip=109.37.159.108&bannerURL=&referer=https%3a%2f%2fviewbet.live%2f

## Fake pragmatic game example
Note console.php, loaded in by (most likely) fake domain ppgames.net, however pragmaticplay actively allows the alteration of their scripts and is involved as explained before, below is example of a foul play 'illegal gambling' provider under code-name HONESTMAN.
Basically upon error (like said sending a false constructed callback to legit gameprovider), it writes to console.php (faking to be local host by proxy windowing upon init so doesn't show up in network logs) the actual game request so a fraudelant result (spin result) can be sent to browser.
Backend to get the game result to bridge, is this package basically.


```css
<head>
    <title>Cleocatra</title>
    <meta name="google" content="nopagereadaloud" />

    <title>UHT</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, minimal-ui">
    <style>
        body,html{margin:0;padding:0;color:#000;background:#000}#Mobile body{border:solid #000;border-width:0 1px}html#Mobile.iOS.InFrame{position:fixed;height:100%;width:100%}#Desktop,#Desktop body{width:100%;height:100%;overflow:hidden}.message-box{display:none !important}#pauseindicator,#wheelofpatience,.scale-holder,.logotype,.logotype-wheel{top:0;left:0;right:0;bottom:0;position:absolute}.message-box{display:none !important}#wheelofpatience,.logotype-wheel,.pause-wheel{background:url(data:image/gif;base64,R0lGODlhZABkALMAAAAAAFkzEZhYH/KMMDQeChoPBbNnJMx2KQ0HAwUDAX9JGgAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphMzdhMzFhZS0zOGNkLWNlNDItOGEzNy0wNGM3YTI3YzFjZDYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTEzQzk2QzRBMzNFMTFFNTlEQjlGN0E4ODA2OTk5OUMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTEzQzk2QzNBMzNFMTFFNTlEQjlGN0E4ODA2OTk5OUMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MmMyZThmMmQtOGU4MC0xYzQyLTgwNmEtNjljNTUyZmMwODczIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOmEzN2EzMWFlLTM4Y2QtY2U0Mi04YTM3LTA0YzdhMjdjMWNkNiIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgH//v38+/r5+Pf29fTz8vHw7+7t7Ovq6ejn5uXk4+Lh4N/e3dzb2tnY19bV1NPS0dDPzs3My8rJyMfGxcTDwsHAv769vLu6ubi3trW0s7KxsK+urayrqqmop6alpKOioaCfnp2cm5qZmJeWlZSTkpGQj46NjIuKiYiHhoWEg4KBgH9+fXx7enl4d3Z1dHNycXBvbm1sa2ppaGdmZWRjYmFgX15dXFtaWVhXVlVUU1JRUE9OTUxLSklIR0ZFRENCQUA/Pj08Ozo5ODc2NTQzMjEwLy4tLCsqKSgnJiUkIyIhIB8eHRwbGhkYFxYVFBMSERAPDg0MCwoJCAcGBQQDAgEAACH5BAkKAAAALAAAAABkAGQAAAT/EMhJq704yyLGOIQmjmRpnpunDgHqvrDbrV4S33gO0Gqo/8ARz9MKGo+TIQvJtCAUh4PAV1IWTYls04Q40K7CIViULdu2IwXvUKiKS2YzWuTlCdy8cSZenmvqPFQaViR8fX4YMzwGJIQjhlqIFwRKSyKOGpCRkhaKNAcIl2+ZmpwYBZUKonlkkKYZakNsg6MYmmevToA0dxmYF6W5GAGVghW/FbfCGQZKjBjIFMHLk5V6EtESytSJSqAX2dvcFwW7K6oWSsbarn4FBaEnsUNtFZ4quBPiTRxRBwr1SHRRgo4Cqi/A2mFBwDCfBgQG/PkL4DADsSG9KnDwYGAdO0Mn/xiKZEgigESJBq5daGYnhsJHI0dW7HTypICAGSgFcgkSZsyYIwTUrAlQxEUVBWHw8fkTqNGhQylqICDAwBQdckQ03ToCItSaHccl29p0phMoX23iXJaAbNkTVNOeVBAvV1u3Mc2OCBBRbhQDdTndxSsSxxO/UZIiGkxYL4p+cp9xItzwCIG+X181bpKAL9SMkvA6/nG4pkc0jGVyghxF5ZzUo/kFIBD4VRYEscXq3s27t+/fwIO/JkC8uPHjxnMLn2SgufPn0KFf3d32nfXr2LHjBnA5uvfvYcUmyE6+/LsECsCrf654GQLz8K9DXE9fMrf4+N/VXw+aWn786e33Xf97wvwXHwJVCShdbWwZWJ4NTyQooAB08faeg/ItpxRlqmno4YcghijiiCSeUEAACsxGTXUM+oFAAALEGKNraBRgHDycUCXjjqdtgQByBBSg3A0FKLDjkTQyAWRxawVx4pFQEojGksa1eENnUGaZJBJU3jikCAQYmSWUTc5hY5dMfmlBkWNm2eMWCaB5XJldwdjmkUUJM56cVcJ1J55vSrInn0HmxsGfMkq124+EBiqBmH8GYKU2KKZIp4nFTboBoZdOgGiee1SqwKiOThXAqad2CsCgXaoKAKRRlirqqKNqqsGJqKJqKwDvtbrXmIqKUCStxJY6Sa6oGssokK5GuGP6AK5OMGux5CTbIgHIohrtpsjl1hmt20oQJrHENolrrgxim62KWJxZKGrkEqtHZ9mu8+K60KLQlpowjBsvqBOci+yx+PLr4r+jXiNwrsDgy25v0xLb4sKonuLwrqYM++9pFJ+aE77GShJxwhl07Nq964Y7h7/xXmqyqesSYPAR6CFM48sZoFyvWCyTqynOJV/MzRMIBwq0LeruTM3Io452tMX4qmwE0RuP8DQGSSMb8hEak7slAFdfoPPAwlBNbrRhE6z10vF+DTa+cMRMjdkpKpd2tbnKPLS6epdwt9jJlfj2uoITCXfhMPyNeCZyL/4CxRg7jvdskTcRAQAh+QQJCgAAACwAAAAAZABkAAAE/xDISau9OMsizjCEJo5kaZ6bN6xDgL5w/AoseyRyru+AWg8hnnA4+rFcxKRyYlwhl1AKQmEwCIKlZss0rSoQ0RLCcCiXn8UmWlPwDQ6F8EhhroNJ2nXGYDTIRWR1ZQpZaiQEWnF/GIGCB1gaeSMJbjWQixQdjgcCeIYiAVoDd5gVBJtnaUZ6FQiinaUXmo4GOJGfGTSJsRdtqKwUkhmIWoS8F3SoihjCjKK2x62NgsbMuBahzdEVAaiPGdoUlFoH27moftarGAqil+YTp7/qP6wFr/AZybSkwdcTuposy1fB16ZqFCqteEesCcIoCAr0I9FNmYWANqBN4NPkhpwCVP+8DBSRYFqdhwDa1LPQcN2JBDA1akAgoIpNAwFkDkMFq6AmEBey9XkZMybFmzevlJh1MobQH+8wFJ2q00JIpDYFjOy1KSqJe0Z6kqRadA5WrF9AUcvx9M3EC2Spjghw9mxODQQUCFDg9US3FWk1xCU7qWZdpEoJihssl0SXw0gVbN3GuLEJDpCRBngbq7JlFAQMZ7bCeZHnsjkS0B2NM9ppmENAjhaL6fWS0JmPnY6iWnRk3YwXIViNtG+YuLxk2wT2h3C0AgQIlC5lVLH169iza9/OvXu+BNHDix8/vqr3QwLSq1/Pvr1x1wjiy59Pf76t0O3z60+suL7///EBoNf/fgSqhxJlACZoX4EMpmedghDG12CBB0YTIYQBTLgfc7xcCOGAGq4XGEEJePgfDsOBOKECm2FXoon2nRfDa1PJaOONOOao4448ooAAAQEEMBl18Zknh2oKJJkkh2FEVMCTCBh5m5JUSqbbk1hCuUgBAVRJJZNLZCmmRBB16eWXx4w5ppQwgHeml2AqoeaYUQqR15teDtnknHTqwCWeXr4XBZ9qTjeTmYAqKSQ8ThKaJZumJFqloKY16iiZX0mqJAGQdnZplhRp2mIG4AW5qA4REYBpBpYSaqgEkp5KqqmmUpoBdOLpOUGrhc4BKKVA0hpkpxf8SN6rAJTo6lxvcuqY+bCm6soGeaqWkACfyCL5JbITQBttL8E6awGux3KhprVAsihtQd4G+RaXtIpLAbnkvdRonce1G6QFqkH7DnjUVosCsTsE6+277YIbMMGxDNduVPBCC1fAAmdnMLRVRSwsBvSOx20sGgvrVcimDkNxdvoyR/K+GBhL7bqlrByknjJPu7Bi/XprXM2kUgzzHxcLayjPt1LM8BIO6ywC0Sa/nE/QtLLJdMsUf7xEztCuOzXHAf8cpr5fJTyCy/Vuk7SwMG/NNbXwKB22t+iS5zXSGJegNtXlfRcuwXe3jOvc2vXdo91iDx6D4IaT5HbiMIQsL+MvQBfk49FEAAAh+QQJCgAAACwAAAAAZABkAAAE/xDISau9OMuizhGEJo5kaZ6b4a0B6r6w262ekcR4rgMq7YW7oHDkYw2PSErR00o6K4mAQKAAlpaHJik6VSCepYTAQCZbiUutCGEYuAeHAngUKNu/JKxaI3i/DXMiY3ZkCldpJAR+fnKBGIOEBo0ieiRti25njhQKkWQCeYgiAZhveJsVBJ5maEV7FggHpQOgqBedngI3GpUaCrNxthcFqwavFb0YBbMDhsIXdauTF8kXfaUHp88UYqvOGNWpzMfbAKqrmkqiFgmypYDlj6u11OsVpLPp8Smr5OESsWbR22cBVyQB2ib8A/AL2zSCFNj0u9DDRzpFs8gdQVAgIZ1iD/8ZFrFh4RKmA7uecJgiIIDHDN08vSLm4xXGUvoyqILjhQQCBSxZBkgp4lykbxQ4qAABbRY8EsQWZaMTNGiVEgbtID2BD1PICwiuYdp6q2pVBV8rEIuUcwSCUmSbMjswAqjZqi5HEdJIoqsbAy8pEHDHbMAIAnfvDtVAAOjVHDsP9MwQtfDfEQnsJrbadttPy346T0AgZfPZtML8guZrYaXpoHnLDQb9RgBqxppfTxbWkPYB0SK4vJ7COsnN1UEKlDYdd47JwruDNH79jLDT25A3NwfzXCpwHaTvfj+i+k3xIa6njEci1g3CbQUIEAi8CbEBtBDz69/Pv7///wACmED/fPIVaOCB8hVAVIAoNKbAgxBGKKGE622SwIUYZqjhhhtM6OGHD2Jny4YklnghAAGAqGKE5zli4osbrijjg/rBaOOFM8pY440wppjjhy0GwiOMP/3oIX3PDFkiQD4aqUBs+ympIYNUVmnllVhmqeWWWyJAQAAEiDgHhtsk8GUAaIJZTgIItNmmMGemmaaYR7DpppsLOqGcnHwGKcSdgCKQ559x9pnmM4EGOigOZhraZ4VBJJqoEHs6yiedQ9gp6Z2LmlCppXJC+uemir7gJah9YpqEpqTiecKnqAagKhitBloCrKAS0GmZtd7ZV6xgImnml2HqwGZHuwLAKqnJohgr/3aNyjlrBRwVYG1HmPVKB6hiFppmsxgMeO214NZ6mKO6+uTotACNO24YmzYbBZ/zmeDtnGARqGC+7lqLJBSTbhGnqrim6ZGXB+ZZbb+zsurIvWjqg2CxUDDsb4AFo3nwxPos3C+4SVraMcfKWPyvbJYOijCCGHjsLsiokLZuyySXbHF/EKtJ88QwWYytfhnLmsHKB2rg8rv5Rfuo0TWH6/PJjgSNJNEGruEzzE7IbKhoVBc4wtME5Zwu0zxbbTHWdVoqYtfyQWVyPFrT61PTGojLMNyOQs32eEdbu8+9fNMtAsNQP3FqmmO7JXjd/UI0YIIn7H3CsT9zCYDkluOAeRXmMGzO+QsTs/s5QAiiPXpEBe67TwQAIfkECQoAAAAsAAAAAGQAZAAABP8QyEmrvThLpIxRhCaOZGmem+CtIeq+MNqtaxLfeA6otNfqwKCoxxIajxSiD8m0IAIKgaJwUhp+o0RAIAggmqVElMvFDpXmDEJwaB8MVLBoSyZ/SdY0RuF2C+QiY3VdJXkkBH19cYAXg3WLGoYjbIlteowAgoMKeGgjAZVud5gVBY5kl0meGggGoQecpBd0jgo2kasZfK+QshOmp4S4RKkABa8HAb4YtI69FZIYlJUGt8sVYsHKGdEWiK/b197BAs8T3RQJrqF/4nvBsRfoE6CvxdfAp5fzAK2v8e5mkRulitiFXaEIBqywRlujXL+QhQODoIDCT+SezehhbcK0RNX/5DxRQNKLiWynJqbokeaYvRMEKCm4eIEDyZsgOmqImbJmlA966lVqR8LUgKNHD9CsQACn03sTNJFRaeJbJXNOFCDdOgAgM6dOA2ClkK8OVAwIQnlldoDr1gOfwII1uXMQ1RNC2xhYOoGAAbdc4YpoKhcsAZ2loAQ4O5jNB77GBAB2ayALlMKGF2LjM9nt2ZGYw46VBapz4LsZClwOfTMAYlJ+TXMt94Iw65uQmwSQvfXKjQS2WaMGQ4B30uEoQLNeJlk2rNc3VC/39dc0bSbBwzLv7FvkapyMhex2m0yW9JvhjWjdOhMfAQK55fCcorm+/fv48+vfz59/ggIABijg/4ACQtdfUQEkqOCCDDY42jJGGTcbFao1aOGFYtlXgISdVYjhhwva1xyHbnUB4onIyUJiZyieaN+KkxHQIobpgVEdjEgpNeOF8WFSHI5IhYCAjDsmCB9+4+GY4oEZAFfkYUxGKeWUVFZp5ZU5DPneg1ieRKSCNQqRwJhj+uIhg1wiQeaaBgoxJI3LsMkmRV9eGGYOcsp5hJMn3olDnnkGUUCdH6ZpBKCA4vBmi4buiaieL/CJ4pHuPBroCWeCSECjclgK6QhPMNrmNZ6uecikkP33HqW/IeDqqACUCisAhDbIKgbArbplq66+mkWpI9QKZpqD6vrerBck0Ouys3oarO6dzRq7ao/JLrvsSYlmQeitIhQrrTn/AYjAa9Yye8Kl2q7KqZbSctsPgYgpW66rKMwJSLu7WkCgRTXNO25/3kp7UbgEVuuvf/humuy+WPlLr34BG/sawQPi6jCypLD7La4Mq+FwfhHr2mTHFvuLMSAaG8sXxQJqIO+89yU8GssBinBxfSGv2ibNAIrwcrma5drugzxz6TC1TeR8rM8ku3yzOEJvzPS+JBztTsoiZ9G0zQdDjW+PRYfRtTghGxp2CfOevKe0yJ5Nws8PB0TxuVtn0ava+bndJQx67+1C336jsC/SgTsBb+ExEPxvQBEAACH5BAkKAAAALAAAAABkAGQAAAT/EMhJq704SxSEUIQmjmRpnpvirSHqvjDarWsS33gOqLTX6sCgqMcSGo8Uog/JtCQIAUWgcFIKfqNEVIpolrSKcBg7VJIzCIFhbRBQvSKCeN4lWc8YBZutgIvmcwEldyQFe3tvfheAc4kahCNqh2uOihRbjIKRZiMEk2x1lhUFjGJ4FZAZCZKTfaIXmIw2j5waAZ+UrxcIpWNlRKcShriauhZyvaEXqYu4ArPGFQm9UrTAGZ64wcbIpZVJtcvO0ba9xRbMl7gG3+QTpL2n6Rvrru4YsYDQ4NcWt7jK7lXgZW5RuHfrzjVBgGAfiW6MAgKY0cPhDmcWjXAIwJGARFXU/87w6nFm2KdtxyQF+OiEo8uOGS9ADLRrBgiZuOyNIHWgZ08DLClAefmyHaxSCk1km2R0YACfUA/oxEe0atN33mAg+JQUloGoUA2MqErWYxxAXU38YyMgqAQCAsBGFRuHbFkRBVyifKhHwEoNPOVGFZDFrt2rxrQIlrsXwBPDZN2K8rQYbFoMeSETJRBTUYG4laEqQIxZM9HOXp6G9nnlxmPTARobIbD652UUG00bU1D7r5DMkI2BXjy6yVC7whe3hvOaKOkjtMEaCIBa42ZyvEVLZoKAQIHtXuR8eC6wvPnz6NOrX89ePYIC8OPLnw8ffHvAsA+n/3xggP//AAbo3/8BbgAAXH5WnVdAfwI22OABBRyH4HXmCeDghQL6NSFy5jGI4YcHbMhheR5+iKGEIsZ2ngEmfmhAcyJydh4BLZ7oGIr5yYjeUzUGGOJ9McAIm45AFmnkkUgmqeSSRyQQn31MZCabEU4SYKWV5B0RAIAGTKlDhFeGCWUQW2aYZQzdhanmmUCUGKAC1QUJpppqGgPibTDMSWeYbOrQYpdApLknnWMCoUCNbd0g6KBrRoOAmxjiiUGVjBLqTho9HuDlopVaWSgTnvQIFAmcVtonHDy2eMB2ejJaQHXvwRcnCQnUKsI0NU4lU6dm4TXfpxTUKmycn5lIlwadPhfrfK4Na2vzJyxeeGwGrV75Kq301QeDs8OWUGaDujpB57UlLPvrBQkw1NCk3D5L6qE+gkfpdyc4mS25waqrLrrtuluIhf6x48e99Fqgr7oZ9esvqd4pYu58FqV7MEP89nsfwR9JPDG7Fq/3sHyTTkwxx9yuZ2+2LGl8sCoKq0dwUyrrq0HL6H0cX2cx78tyx+ZhPLPIkik8qx82y/qzyFnw7M7J9AUNdNJKO0pwFk9DXfI9Pt9a9a00R8M0s1QjTWvUutw7a84jW+3sPR/bhzaUZL/ydZZv17t2eTKbULfdCy+5N5M4/A14kFsPjubEQxuuysaKB45weREAACH5BAkKAAAALAAAAABkAGQAAAT/EMhJq704SxSUCoUmjmRpnpunKgTqvrDbrV4S33gO0Gqo/8ARz9MKGo+TIQvJtCQIgaivpCySnp0AollKRL8gU7WrEJgFiik3AwVHt6QxKXA+K9Yi99cqkosKdXVqeBV6X4MYfhplgWaIhBKGX3FDfBgEjWdwkBUFkmF9lSIJjI0BnJefNouiGnSZAo+oHJKWFooWgLCnqKmSmxe4hbAKq71On7YUwhO6mcrHEp6SsjutwcTRrp8ZzACYsNXa04bQzAiwArzabKrB1xSvmcDsFrTl7zyIzqaECQjGSrQxRA/ADBoBJZQKVGwNgoEECmbwUsseD1v8AkG7xChAQgxY/9wU+IiBnJ4LHDyAqgCu0Z0SBRQYmDlTgMROtcTFw/eiZSCdErzQHGpgXbtkNyncAwMUA7p+IzARHSog6qc9JCkMjLKRhE80SaUJmDp1hMmrOgu0aSqCQJkPYRHIJEv0pYaQV7myhSSU7tSuE/DmDRCx3gSpfokCrvBwMFZ2MRPX3Uvh7FUCWdcEkEyVspOtl48R4FxzcYnGeU0bmSvZoxG1eY+NTZymieU9x1hPFaD6huBDosmqy3wEtRRtm4dqiYagwMh6bj94Nky9uvXr2LNr314dgffv4MOD547jIYHz6NOrVx/2WOQD8OPLnw/fQG3z6/Prb8+pgAH6AAZogP9z+hW43nRMKBDggvSxYOCD6Fn3H4MUwgfhhdZVqKFaFxaIIBICaMigAE90qB9xqBAg4oItJMChiec9d91oK8pXFHkxlAhjYTj26OOPQAYp5JBI/OMdimtM05sRzTnnHH9MBDDAlAMYsGQOTTrpJJJHEEDllwpAiYOLWpYpZhAGfPnlAa4VmWWZWh5zgJpqHnAlCW/C6eSZQMxJp5qx/JCnnlv
m9uefYfpGKKF8AoFAmofWadQJgy4qI3MKREqnlSeQaamWjTIBiKaAQunppwWEuoaKpFJpAH+VwgnQKN9xmcd/nE4UgJ+kTnoBqpdmIJ6tGAigpl1OGUtqVX9Yaqr/eKpK4CWdi42mqQEjxHomtLO+oGydJex6KLIZyEost906kcC6GEBKp68gKVinmE2mewW6JK2rL0mZHnrmqFMOiAe6Eu27by6RkpstAR+iYCS0IBnM7i2RNuwQt1lJPDFjkWKr3cPiTaQxBlIeeufAGIsscQa8gosdwXeNfEmk8GoDcnjEaUzct3RGWxy6o8hcUqTMGnbzeEGvvEjF1OE7gs4iINCx0UA/LXQGJf9ZMyROW620CC1/6XE0R3/XxdVsRFpPylegnQHPVB6wNsRnf/3Hn0VrE7IJUIc7L3VGEhuU2xpYe0CiRAZGeOIu9M24b4s/znfkktetb+U5HGxYAQQAIfkECQoAAAAsAAAAAGQAZAAABP8QyEmrvThLRIIvWiiOZGluXhqAZ+u+Z6d6CWzfODCnbO7/od0HSCxShCuj0pIgOAkIE7InanqgS5JVRQ0Ku5lEQEEmR7Mh2aw2mpLGZXIAnRYS3t9RIR4/0y9IAX4abiJwfApgfxJqM3eGeWmIZYOLEwWBihWFYZNylhiNKgRsGZyhngqVoCingJEYCKmPrBaiKqtHsICppbUUWzu0rzuaAHuew78UmEi5Eq5HnnPLoUjKusWonsbLCJkY0QAJqdTV1na+E+KHiM/nAN/XxDNgyJPYRgkI6iLNQqtuBejXjk8/IgkKPClwEEMwRxbkcbFwD1G+DJjkNKzQ5MnCEv//IEZUo4jAtBLfBKhUqcqfx5fvKgi8KMLkpG4TxKzcKcAcxpcvC8RsVe+FLEQ+M5jkuVOBS6BBN0oIGYDmCJtxpB5TwJTpU6hBQ3BwgvMqnIEaUnbl6bQmWKhDWelcy9RqToVvo8JjxJUuT7sVxub1WDbLHr88BbnAO/iJViUEEDctHIbxYMpACkhmCViL5be1AmxGC0QwaFZ96SZR8vllaLoKOt9ICLdW5K6yfSCwjJmI6J2Ka+1meK6DgtV7kytfzry58+fQn+9DQL269ev8ottIWKC79+/gwT8GJUuAgfPo06s/L6Al9/Dw44//g8D8+vv3BQyPzz+8cgX4Bbhe/yL9FeidcvYJqKABBjao3IIQ7tcgfHEtAiCEASrw3oThzUcHARgGeMc+HH6X3XIghqhebtpx1BhUHrYo44w01mjjjThqsE8CMRbBAXJyXdfjDwEcYOQBAvSGw3TYDYkDAUdG2RIaTGJHXS0CRBmlAaTpY+V1tWgppgEsavEldrUYIKaYifhQ5ZnUOXmDAmuuOSUMcDb5CwJq1qklly+8maecOcjip5gCsCgonIRmluWhUla46JeNGgEipEcaEFee1lXBY6WMmJeojkViekBSF3B6oo6f8jjnALDCimoFe2AqgAiDjtBqqzAQEOuvgGl26K0hTOrhrp/CIMCvsRrwRvufYs4aEZolIJvsBVDCmuQFyzIrqxalblnhONX1aK2rFgTgLRgKeAvrAeNudeS2VJ7bTwLuEsuMu7C2hVJ3i9iLLb8XtOvuAUpaYu9B6rqb6gH86svcwuEQDAi/A5T5h8AVO4yBAfw6OzHHF3s8ML/SLkNyyd5q0K238CpHsSkWY1AAxO76C8/KLDMbgsHuJlzEzDSbHAvO3kr8C9FFtxwExhoDwXPHTocAsrsiq3xuGzVr4OvB52zNtdEug12N2IZ0rcHN3uq89K4lNFx12r9qmhy6caudxqN34ii3zzne8Pevgd/w9dyFt4Bv0onbMPgAQjc+QbYD0FtNBAAh+QQJCgAAACwAAAAAZABkAAAE/xDISau9OMtEQiCFJo5kaZ5b53kh6r4wqq5eEt94DtA0ov9AEm/VChqPkiELybwUCCCfSRkojjgegq1J4kC/UqHSqkkMw9zM8/vdjqjkzIyWFrHZcQycVKCi6xV3bH96Y2KGgE6CUHkWe3ZUAW6JFAiLUISOiBlmVASUGGuLb5sYczyZoF6LjROPGAiRn6Chl1oarxeRkrQYq4KtO6UVfbm9xLapwkOtu8catrO6wxOnNMHHlpeNxhuyzyKigpOu1ADWK8rgAL93ed2xnonkfLb06PS79EYJCAX/CPbJ2WYByzULxcypCaBAwS0+/yIWUFdBG7ALlrLkQefBRKyGIP95ifAnUSLFCeK+YFuo5CQ7AiBjOhxBsmTEgDQXubzQiYc0aDKD0rRp82TKldCGCETJMKjMoUSLjnwyMUfCh7CaOo0ZAGJUm0uPcdjqFCmAml9vhqUEk2zQn1fSSgXXx63MADsryi35rK3dhlVwoE2bF0iBvyDhxui312wQrW6x/kiwtxdkp3ibDOZL6zJXxzc2F1iLxK9MxVwY33x2WTKlfoWRFCMQe53t27hz697Nu7fvCQmCCx9OfPhvHLARKF/OvDlz0qA+CphOvbr16QoyJ3fOnTt0QAgUXB9PXkH38+dzByDP/jpe9PCX525Pv3r8+/Pr199+3/n3OuLpx57/Amf1151uBAjI3iz89fdfIgkqaB1qx5XQTjRsPFjhhhx26OGHIIaIgnC2aQNaEMVpCEQABrRogAIn5pCiijoQ4OKNmdUxI4m0CHDjjQKIhMSOxtHy45ECUIgckTyC4uORP8IIBJNFdgYllELCQGWVtCDw5JVAKinCllz2EguYSJ5IZnC5HYZmlDutSSMXCb7pogCkrTmSAgMMcEBXOMAkwEycsGinAYCWQSVNB/TpaKIvKHDApJNCipECdhI4JpElCODopzFKQAClpK5UwJdQaqrojCUQ8OmnlpogKamTCtAqqjh2UdwJBrz66AU21pqHALRSKiYFZiAZZ5MlBOCr/6OKOfvpAXHMWqwB/7nZopSpNfqsAQV5+6mtxBRLaaxT1Rbps30q5qqvB1xgbbGh1lEAuwOQW4G0vmJkgLkHqLqbp+y+w64eAB9wbC/vPiswBfy+msG/5uqbW6/PHiBQxJ/KkTC6rOEL8g4HZzAvqQaoe0QC4r4KbgYcO6pBAR/jxie7YsbcpwgBJFyvYfharEvJGSBAcbEP90LwsxTpPMAbCS+smchvEK0BseYmzRa7Glf9LAmjmvvyMfc+K7XTJZw86djHYPwp27hYPbO5IwNC87Rmod0srSmXiOmLeel967Yq4ya4iDccjjgMDU+7OHIt9yn04y5wTC3lgfZ6gAUAP/8QAQAh+QQJCgAAACwAAAAAZABkAAAE/xDISau9OMtUCCmIJo5kaZ6bpxIh6r4w2q1ebN+4RKtt7v+inacHLBoBQtZxeUEUQIlTkijieApRZunJxZqmpQQhQA4otSJn9/kVUjPjMpmAFq25bwx4hJDLs3UXd1yAGntBfmV5gQBqgySHGQWJZYWMExyDICORFwmUc5cYjnecboiglqIbmpuGpxl9oAWro62qFJ0VcYkEuLUArYs6sIKgAbTATbdwxRa8fnTKGK3JF7oSk6DDypmDi9ifoNLTtpp6zhPQfr/lAN53ebqylNbuy5qqMzTX44EIABG0o6bpjRgab+glsjdCm5mBFAJKhBixoKcZrio4jGYCwboAFP8TSBxJMds3GBvlcMP0MVSakTBJwCMEQxzHhsfI8IEJkyKpjC9S+rKTs8wIkTx7VnEiEEcHM0NjtaREImnSkpfEFJXDMJZVnveybeV6AunXieVSFj2DwuxZgMqmzrrh9itWIGqPdY3xFu4quXKi/qgLdtVWtkYIS6xVdG9innd/5EW2imTcaJEHJ8hs5CnisKBDix5NurTp06hT+9jMurXr15zR9FFAu7bt27YDtIDNm3doBLiDC6ctsLdx16ADDF+e+7jzzaCZS6f93Hn06cyrH0+OfXiAd9phhy7QXXiy8MhFEyh/m5xqE1aSJPHyvr79+/jz698vSIEBAe7V4tH/B8AAN8CBByoQlwAMCqCAY0sEgOCEA3z3V4MY6lYHAQdQOKEBtSiA4YgB4mWAhxQeUMuILD5YhIEoUgjiKiKyOCJlOUgYo4cl1hGAjTaCZAMBJ+5IoYIC1ggkhgr02JAARqbo5D8/LjmiiyboGCWCFrpDnpU3rqTDlggqIKYo64HZoAIUFRmlARA2osABBxgw5RciNqnBJ2oyeKcEWx7wJwJuHtjlCwEYoKiihzZRpZVIatDhjo1ioICHB5x5zaKcxpmNkjZGmsGlKApwZgExVlqCf5wqKqohoGbIx6QIwmlCoROqSoAAdWJZAaut2hnGo2ueCVyHBqgKx44lBkDn+7O2VpBosP/dNcmanuKQAK0yWpCAAc8++2ow1DKKAlOBaMnjM+FCe8G01GpaGbcTjguAs+3S2US5Bth7D5QoZvpuvvq+y2+2f1GKAb75ZiBAuQKMhiuCB/zCcLtw8PunKOpSOOXF4WoAbKsCxJYYvQhGnAHIz2pQAL/K0rhjnCwXvPLBXqKcoAg1q7jnw9T6ewnAmK7UMycaT4OAwjwT7LMIQAcr9IYxztg0wSS8TK3KwKCK4sb3Or3q1uVMzPXVDVdFbcyBFMCtAZoeXQKRnJbsDnCMyiv33DUKud/e/CEqduAwcJiv1YS3BW67UyeuAcjROu7CrnT6qkwEACH5BAkKAAAALAAAAABkAGQAAAT/EMhJq704y4RKQYkmjmRpnpunfmjrvm23enBt39KshnjvjzoP70cs5oJDo5LCQYBOwUISuFuanNhnKTrNJAjgcNdqaWYRJu42HC6QRWfs+KIeIdjs+RsQl5PqInhsaHsXfVh/SECCYoUXZnF6E4AYX4wEbo6Gh4QalHSXBJKFnKOfFZaMmZqPnCKnFAWhrBqlnooYd5edtGW2GLASoau9m4cZwbK7xV6/FrCpgsTMFpy8sbgVyoyjzM7YOl26qtQikGeGQaCXewnu7ijfKTPXfKH1nnkl7/wn51mtqjy7NK0WgQAIEYoawa9htwmHHhq69PBLwosBCDB02JDEPy0t/6K1+XMQY0KN5jg6ZHhGIjBBo+6YxIgypcp+5vzYGCfF4EyTNTXc5FiuTIGfM/E9GrqyKABZSE0WtMn0HTWZUS8udFEVJ62jWU8qNdHVKisEYRVOfVGWVsmsPYlUdZuVwFgcQ+n+tNuO6NeZmFh1LPZWoUunRLbdRcy4sePHkCNLnvzDYtqThylPCDCgs+fPoEMHaIz1slgABEKrXt056FXTPxEcYE378wHEhWGfrM27M2LdP3vz/g3cpADhrAUQL36xAPLVa/8yR+imwPHnnQVE7wW2+HbNlaKIFwK+vPnz6NOrXw9MgQABrs+C+a4EgQLQCggr2K8gAP0fAcwmmv9b/BUYQGYuEGBAcrQEUOCD8flgXW0G0PLghf7JpYCAtCnHyoUgBrCYCQEKFyEZDoJ44VYvKIjcaLTYpyKIJ75yXW8G1PgGWjNi+N9mHNZ2AIzlHNXjgweSkFpvByiAoBUEHGlgNzd2uJ19BhwA3w0H9bfdF1Lup6MEQaqWIxxZHqDmkDUE8N6bY/J4JJEZlGkbnRlsuOaaI2JAwJuA0mfkjHhecJ9qCvRZwJ57jpmBm4C+l5+SMzqKwIKfaWeCAIyuWShqChggQKIXQBrplh5FeWGf9qmJagkEdLpmQQoaYKuo9ZgaqZNXpNhfnzUkkGanHjJx67GTxnLqm5/WwsLfGwHKegCtx95aLAW6RgrsWdI2eUGt1VZYzbLvNVuOnp0agA+41fpJrqaNxSpts+wemye5ySLGqawGzFHvrRn8Sa6jjsgra43/2qpBtm/yWpSw0l5rQcLiAvOuuZpEK+t2FIvA8JvbKrGotPl+G67CQrm3LMZ7oMuouoGcXHHA7/5ohGzzjtDxCCqfyjKUESsp8x/4MjNypwTvPMLHJbOy755N+zk0CQisTE0Bwx4As9AnmyBww0/+gFa5LilN6ahJrmc2ey2szfYJCUv8NlknRz0319aGfDcFUdpKKjURAAAh+QQJCgAAACwAAAAAZABkAAAE/xDISau9OM+EetJgKI5kOXUo8pls65pc2r10bUsyut58D+Yen3BIAaqIyEtiuRsZm6FUssRklp6kgnYLnSqrViewi0FstwgvCFwV58iWxPms1rDD0bFofobX73gaWD98W3V2gCKDGoVaaYcYgEt5b4SNfpCSlDKYco2PkJGagnoZZo2ha6NlpUqNBaCponeklRivBbKqiay2FqeFmLoAq7+tFa+xw1+8xr5Fr8shkmSLG8l1BQTK08UbQBfAfGoFBgPnArkk1OGcca/CFWYEBAXxAAgH5/sDCtwZ3r4F+fVpnTZ6COMp4McwwIiATi6JkIOwYr0Q5hjyM0BgIhsahf/+WThosSJGjRrTdWvzQpyWKCVjhliIUqMCYYFeeIK1hmRMhOoE6avJ8IBDaSN/xhQpLyPRjR2R4lO6tASBoU/3CWCqZh7VivZaBMjK7wDXJD6/bqOBQADZcwpkIVCL8CwJAk6JHpCV9mfQHgGw1pSlNiyRBDRR7k3Vt6JdGwXcajwaam7Mv2rw8qPM2KLhVAQCBMCcCtg9qahTq17NurXr17oShBZNu7Zt0QROw74Q+K1Go6tl3x5+OzcAAr6JRpUqnLhz2rnzJt+Yevbz68inK059vbtowdrPLZbqvbvk8Fqrl3deD/z0A6SHFVhPPFdk91kPqFQ9n37t+LtNhMv/J7oFaOCBCCao4IIMZlCAAgIosFxs2jw2BAIKHKChhnHpYp1oFt6QQAAGbGjihIf0Z5txXhAggIkwCiDLcyj68CCMOMqYSncAthQYjjh2GIp3a91AIpBA1phZeSy64CKSQHKWCX09MpIhlDFW6UVz5WlZwY9YbsgRagjQ16QGV4W5YQAFkkNfPC+qqUCVZQpggABKmmCdlh/SiFGYeP5gpwGEGiClCQEooKiieZ7QJ3F/ImmoCCQWWmiIyCyqqZcqOjcTkgE8Vo6lhTYKQqKaKnroLexFUaKJc5KgAKmlXkAAhAKEyluqi5pKAZe13VMmoYHeRWuhpLkowLIRcnMr9q+K6jZXbZi2kMCgtAq5AbPcHoohtBLCMIMalR6bLLfMajsBqtBWewgCxxK6qrLo6lgBYuCuKtWsx25la73LYvAstF4yFu+k/wKcAbup6rsMtqTaawG96DoIbrjVHdwoxdxqwHCqbSJxbbzqVsAxs4Jc7Osh5dJa5ckBo3mxu0KMeqzDEsAssRIX41wHv7QKIIzOIQzMa8FIwBvvykSH8PGiPk9hc8QiNA3Cg+AuM7WlBVt9atbLAF1oyQIDvLMp0K4sNcT+Vm32XQ2HLESZqurmdQjzKRDAmQve3WALfv+tJ8BkC74OwFEbjia6/ihOw63L6ipNBAAh+QQFCgAAACwAAAAAZABkAAAE/xDISau9OM/Ek/5gKI4k1XVlqq7qebJwLEsuOt94WHN571c7z29oQSgOAwOBFCwlEAghMYRADq6DwKg5gnoR05ACSy6IuNSvN/yxkgeC8+6sXrMzb/IShP7UvVJ3FQZ5Vwc6c3x/UIIYBIVXWh99GYtRjRiEkGAalBdPi5gYBZADCpOJGpaBohQCpWYZnhWWnK1FpXGyqZ+rtxgBpXufvEWWvxlub4cYszTHyI6lkhbOAL7RmaW2JsUb0NkXpJCn1d4S2GEFBNxisOY1F7VsBZpwsVSl5UAuvYuskxAUKNCukrIBBxQABAbJQDMb1cApGkgRn4YxhQ5Qa1NIVwpQdf+6VKxY0IK9QkpAPMozLMWfhUVGygTxqtQVARYvYMTisUXISTKDgghm01AAmBIIGDhgYOMKkEifBZVZktbBUgdahrs2NWjUCQhqFr2Z85fArjK/VlA6FouCqncSoKWq9kKAqw3hTjk7l2LdSjuL7mskt+9AvSQKiMXaii9axCoI4MXCDFPfSz8S3G3YGO1fGEYKaY07FXIOtlicNnJM8BeBAAHKYoK6tbbt27hz697NO1sCAsCDCx8u/HPvCgGWHljOvLlz5iltyyVOnXgBD5Kfa9+etfbv6uCHJxDAvXzzntHWhV9PoID598trs58P37zDrfPZH6m/fXD6/OHVw9//cwbIdgsCAFYHRgEKKMefAQoYaFaCw5l2nDy1hHLhhhx26OGHIIaYWAAKKDDabIcdmJwBLDb1SwGwwcYOYQEI0OKNJ6oT444EGLcCATbeeKN/d7y2444SysCgkEyid8eRULbXg2ZMVkkkG0ZCyaOFKgVZpZA5TpGlljz6WIFiX1apWlxjkhljkoClyWSEyPzmZpRcAqCUnDcKECYmCN55ZI8h7Mkni0fdto6gMRL6QYOHvqUKiQKYqKSMcMLIaGwgHIrTJAoIIKqof6o06CRtalkqAF42uSoANY46ap4UaHokZIG6ueqKTCYKgmKyjvrqBanCJsKiWsJ5TasQKjtB/6jBkioOiQoEUJKbzgIgV5R1IRCrpSMAGa2oZRFQ4rmSruXmZ7kGMOMUCUAbLZHxoluiat6SOew3ZqoQ67hlMWhvicS6SasgYY0rwJrmDnylZvrq9m+0JTU8sCPY4gbsuDlabG8Gd+Imb7BXJuVwyQDYCmW2RSr8qSMna1AsbP36EK/Ca07gMbqTRhzOxMEmufO5H8xsbTYbR5uzzjF3oms2QI+qUNFNa6DykSz7kDDHKlWtQcgvKowyBUMT/KubyCQtq7Nlj002mdGMLOrSa3nd86lpjzx1oXZbDWXNOHhbraN8OzyijICH07aIMSzOOAsCX/z4Uw7TPTnV9h58+QgEMN6reQ4RAAA7) 50% 50% no-repeat}#wheelofpatience,.logotype-wheel{z-index:0;background-size:0;background-position:50% 50%}#Desktop #wheelofpatience,#Desktop .logotype-wheel{background-size:3% auto}@media all and (orientation:portrait){#Mobile #wheelofpatience,#Mobile .logotype-wheel{background-size:auto 4%}}@media all and (orientation:landscape){#Mobile #wheelofpatience,#Mobile .logotype-wheel{background-size:4% auto}}.scale-holder,.scale-holder *{margin:0;padding:0}.scale-holder{z-index:2;-webkit-touch-callout:none;-webkit-user-select:none;-khtml-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}.scale-root{position:absolute;top:0;left:0;height:999px;-moz-transform-origin:0 0;-o-transform-origin:0 0;-webkit-transform-origin:0 0;-ms-transform-origin:0 0;transform-origin:0 0}#pauseindicator{z-index:5}canvas.paused{opacity:.25}.pause-content{position:absolute;z-index:6;width:375px;height:30px;top:50%;left:50%;margin-top:-15px;margin-left:-187.5px;overflow:visible}.pause-wheel{width:30px;height:30px;background-size:auto 100%;margin:0 auto}.progress-bar,.progress-value{height:9px;border-radius:9px}.progress-bar{position:relative;top:30px;background:#505050}.progress-value{width:0;background:#e38a21}#PauseRoot,#pauseindicator,#progressbar{display:none}.logoOn canvas{opacity:0}.logoOn .logotype{z-index:100;background:50% 50% no-repeat}.logoOn .logotype-wheel{display:inline;z-index:101;background-image:url(data:image/gif;base64,R0lGODlhZABkALMJAIGBgczMzLOzs////+bm5kxMTJiYmDQ0NGZmZgAAAHR0dBMTE6WlpVlZWSYmJgAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTExIDc5LjE1ODMyNSwgMjAxNS8wOS8xMC0wMToxMDoyMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDphMzdhMzFhZS0zOGNkLWNlNDItOGEzNy0wNGM3YTI3YzFjZDYiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RUJGMDNDMUExMTM1MTFFNjgwQzNBRjgxNjE3MDI4MDEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RUJGMDNDMTkxMTM1MTFFNjgwQzNBRjgxNjE3MDI4MDEiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MmQxYTFkNGEtZGFmMy0xZTRjLTlkMzYtYThhNzQ3ODY3NTAyIiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6NzUwOTc5ZTktYTMzZS0xMWU1LWE3NjYtZWNjNmFjY2JhZjE0Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkECQoACQAsAAAAAGQAZAAABP8wyUmrvTjLxcgIhSaOZGmemzesQ4O+cPwyLEvIeK5Laj0cu6CQ5GO5hsjkpLg6Kp+UhSIQYABNzBZ0m1gECGBwqJR1cpOAcDiwIDPN5+FXDQa4i/B4cE4nXEVlekkdfQQCRG+CSAeFYiOBikOEfQGPiZFCDo0ECoCXmEFpjW0ZkKA7Xo0GGqanOg2bfxatrjkCjYcYtLUyjI15Eru8MQaNbBfCwy8Lm3YWPTWyyl0OpCYKmw4WND430xsGVAEA1iR8dM5R0FpbC+UiCwLi4ggmBaoXC8UDAmNP7gDfYUAwb16/Erf6rDoVMCCJcAXnGdAmwhcdaXoaahwBMeI8ciL/EKDDpLHkiAYePQKjcMCAAAP+BJXcSIJByogHv22YSXPEAgA3I06cxtPkiQM2g85TIFBR0Z4vCshTSoVB0zhPG+aQQpVKJ5JZ3WUCqjRXpLBKkCoFW5RLg6lCQbU9wzUiRqxGBTnoGGAlXoCuHBQocFWn4cOIEytezLix4wkHIkueTHnyYxRIBWjezLkzZyuGw86UcMCz6dOa7zIUPRoA6tec0/FiXRS2bc1Eac9kcPs1g9y6NSrojbqesuC7iXs2UJgtclJSeCtnwDT088vYs2vfzr279+8yFjRAgICiK8AkGxhYv94vlwWTzespwL6+AdXtKh+QD8UBAPv1GaeI/wP6RdbcVggAaN9XihQoWTVJ0KegfQIK4mB8Qhzw34T28RcHgRdKduAIDijAIYD4cQFiiAbCsECCJ9angIcDsvjgiCzFWB8AKdZo434l7KXjejEdt2KINFpgoo4IHFiAAgCUpwN8LWpAJYsj6jjjCAgA4KWXPYog2GCDJUnBkQWaOcGGCvJIQgFfxoljPmTWOeICaFKmpgTqKVhkBj/F+eWeGRxQJ5lhbuAgjmyu16QJDQj65V0LFIBAA4RdYOihg83ZRWWEThBplKFO4J+kXgrkAHmsNqAqp2SisGKpOUCJKjDjsUoeRpXCWgCtE3iag4aoglTBi7qSB8yYsCYmRcixfyawarLkYeBrAYliAieq1VkwLbUYMMupsFgV6+YF3yZbqK/ZCtIlqhVWkK6ugF4LLBfEomrmvKxqsGmz09gqqXv8VquBvcpsi2pzBcfr7bXkJhEoqtGeSa3BB7PLy6iSMphBwz5BfJ65YYI8wr+HtpvEqZI6jO7FLlvQK8ByFRuqySf7Wsu7cVbsLcz2cHovEs9+GfPLF5swc6yzFdBAAyrjTAJ8ZXonNXgmXI311Be7tzUGueqq8tfSJusq2ShUeukBESMRAQAh+QQJCgAJACwAAAAAZABkAAAE/zDJSau9OMtlAhGHJo5kaZ6bR6xEgb5w/BosG8h4rktqTYS7oHDkY7mGyOSkuDoqn5QFQiAwAEvMlmmhoAIW0NKCESiXnUQmWrMIDN4DgiM8UpjvYFJ2nWHA4QJ0IgJ3ZgBYaiQHf395gheEhWVzaUV8F26Mb1ePFR2SAQZ6iSIImnCOnRQHoGeVPpdRBKcDoqoXAK2BInsiALQDqbcTba0IvKQYDsCHwxcIrQHCFb0ZArQEzhgLkZLNGNUXBcAN2hgF0ZzUyRaZmjfmGGSgDBnhFQrA6vETrK2x94jNOmWLHy5d0xIElGAAW0KDCYqBUoCJyb5FtCgKWuDgYQZorf8oUaDhA16Fa6dMQlkAgIoABR4htdIYpUcTCxhPxRIyxqXLciXQgSoYpQMBBvsSmDq1K0wDnz6tlPhUiCaKBrREQmkJ1ScArcpAJSWxgOAjrl19whTRoCqOpXCkPSqQtisDoBkOAGAAYOwJdHG+qDJQt6tUiGG4FO76FXEYB4QX+0QQ03GOAgwkuzRQ2TKOp5oFHPP8RLHkeqShHIhcODUdzHW/uS49pavf2UIcoBWwEzcSBwUOdPZNvLjx48iTK19uwcGB59CjS38OlvmF1Qaya9/OnfttcwvCix9PfvwEyN3TqzdQPV759/DDJ1Cwvv52qwbj6zdvv392x/sFGJ7/f/bJxo+AASJA4Hp45YfgfgAs2J1gAD743gYNRCghAA0Md4uF5Fkn4ogklmjiiSh6tkABDRTQ3oceKlEAADTS2FtiId5ygAI19vgiHfA94gACPRbZYCf7rZRhkUWOBqN+MjIp5ZGPICjEjlJK+eNKD+YgRZZSfsdlly8ssCSYPVJ2oIUoYIlmjQps+aSVJOj2Jo0KiOkMmyOciWaHIhzQAAIu6sCRAx2JwKcGPKKpJlsIRBqpnIpK1xmdjIKZpyKSdirDAtMJR1aSIswo5Y3EdNoppcqEyuoG8ZFAZI+ABqWqpO2BWkBwrYYaY5C2KtDAqxIMeWuk06y467IXgBqq0Z5RmCfIoMdesuy1ST0r6mwHHIusBcpeu2uz2s4mhbdJhSsuBtoSe0sB3lK5gbjMkvtsjEh6i8CL6l6bgXOukgbvsfLOS+9OzvpqmbHHetRvvb2Gahm1t/b28LgaaIuvavrGdPGNCU8H0bnHfvfxCO0aNPCtBUdxMKohW8qPvpSePALA07mLBMmqohrRy2SVC563w9l8c8DxrCypzz8fbILC7lFM6BZAiyGdzk8csCu0BtN7AkcHJCqi0SmOQHbZbFSN9ggHc132w2tvoTWvBkUAACH5BAkKAAkALAAAAABkAGQAAAT/MMlJq704ywVEMIcmjmRpnpsXrEGBvnD8AiwryHiuS2odhLugcORjuYbI5KS4OiqflYaBAXCcmK0TgsFQLKAmg2A8dhKZZs1CQGgTAlawqEEmM74kbDpjcLsZciJidWMKJXokB35+eIEXDIRkcSKII2yLbUCOFh2RAgB5aCMNmG6NmxQOnmVnRXsVCwGlBAaoGJ2RgJSiGgCzBKe2E2urDbuuGg6/hsIXdKvBFZUYDLMBzRmQnswY0xaKs6/YCQWrApoW3tKzN+MYg5G13bwWCL/o7qnm4uobsqWg8mFQsOrOhX4JfJUKEE3gBm2REFzoUQNfAmWzJAZa4KChhmee/6LR8NGuQrWFGxUYWInA47tVGims8bEHXClxGMq9AeBSJoCVQA3g/LYqIKwOHywmIFVKFwlVA6JGZTiiQNCgAJRewFUnJooCsyapASC17ACjGVReDapALAZVkbSOWACQhD2zZQmMULs2aIOe5Ah5fWHPT8kMBwLgNatXhNW+a4deVKlArgmdAXgmY7AY7+EMPyFfzeqwAtnOeC0PQyB6rZfSpFAzNmbCAd/WK2mPSyzbrAHAGA6Exm1AczMFvcv+yPGYuG5UBZJHJfAcxwLWuNFu4pxc+w4HwyE3UyybgdshzV03E4B6uZwFUtaqVhIdL4HB729LhmLArHFhCxxwAP9wYFj1yXmlJajgggw26OCDEDbjwIQUVmhhhRHKcIACAHTo4YcgflhZhiiAF+KJKFZBogkIpOjih/iteMuLNHon4wUc1pgiNzdmUICOKe534wI5AikigUMWUKSOChSAZI9QRinllFRWaeWVVwZYwIBYaojAl1/OB8UCZJIpjAMNgKkmghuVWeYmCxSg5pxCIuHmnU/CEOecfNY5BJ54KnEAn4T6KQSggQqBJqGE5nkoonfqsCejfLLZJqSR6jkopXQ6mgSmidbG6ZwNWNoMqG6acN2oYIoJIKpvVsUqAk6K4EABW3p6QawiwEpgmpzWKsIBuBZr6lyhqgEqCcASWurwU8VGa12yykKaCKOuxhltsbomYG0J347SqQnEbosrghwJyGa44FKrwQENNCAsuOZya0GAAua7K7vtmhlIvbgqle/A6PK74K0AR4PvwALuiyiEAG+5K8P6Ogyog+XWi8HCDG9ssEPa1rsuxQ17/PCCGZubAccDV3txgiGb6xLLFZv8cmkRW0ZzySt/LGHEPe2sGqY4A3ys0Mie7E7K285Fspg+Q2e00ySTQPQ4MUcL9dP9umtLwlZzbbXS2DAtcdhVd52qO1m76q3YaneLhAPqnoC03bxKeXeXqsLNN9oU/30CyccKLlPghqtK9wGFBxIBACH5BAkKAAkALAAAAABkAGQAAAT/MMlJq704y6WYAIcmjmRpnpsnrEKIvnCMKizLyHiuS2rd7sAgycdyCY9ICXFlTDoniwYAoHCclj9Tw2BALJ4mAHfcFGHLmQUjwA4IrGDRdjz+DpdoDKDdNsRFYnRcCCVnJAd8fHZ/F4GCBnBmeCRriWx5jAkIj1wKd0SYFAWWbYuZFA6cXKEThhoLAqQBAKcYm5y0kqAiCrIBprVQqgYFuj6sDr6EwRcFw8AVrhgGsgLMGY6CyxjSFoiyxdcXB8ORFt0VlZZ+4hgKqrkX6BMNvubtqMOY8wmwsvH4LNx6BABaAn69ZBkM2G9Ygws9aqBJJuvhnwUYUThTBY2GjxsW/6iRshZnAYIpABos1KPKIgU1xyxQJMXKWyUFK18qQIky3CFV23R6ANFMFjsSqQgoVfprRAGePBXUnPDukUuNsu5hWABgqVcCADFIgcrTy4hUj7SWWEDK04h6X70GeEuWbIGcCTaO8QmjHh8BeA8IiPt1rogDdclKFeEAgQIEalEcWCMA5ysDhOOCFHEyMdQqDCsoyEx4ar+nnqGaZTiKdFy+I0ymhgo7mIPBrr0awIvhwM7ZU1YHQ5Db65scqIHX/nOgONPlMKIAd1sLc3HqQRrPZoab9O4nvhMHzcSAdJY4yXlGBlOAcICrF8dOMZ2kq9eC1xYccMAbDDkGoIUm4P+ABBZo4IEIJhjQAg406OCDEDbYn4IYONAAAhhmqOGGGjawXn7lDSDiiCSWKCIBDHxhEocstijcggSYKOOMBCxQgIs4aggdMwzM6KOJDOQoJIYCxvjjkQMQcOGQLsLXDpJQHsCkizsGIwCUP/6y5JQdTvhHAVj6WIx+WzLZwAFeMtKAkWGe6CSFJRzQwJx01mnnnPTBqeeefPbp55+AQuHAAWgGCoQDBSSa6IeGnqXoo3c1+oJ+kD6ap6QJHFAppJcaiuimnGIqgo2gVpqmn5SWCimjjWqqqqWn8knqq4rGKiutirIqqauvTqXffrZeEKwMtBbKGKHIDrsBRhll8qrWroMiiywOzFabyaeV6iqBtNIOW621jFRqLFLcJrsVs2l82ywjn45Lwq/lugvFt+eqqyy78e4nrL378psgvOUaZO9CA9/rX76RDVyvughGG2+6DC9Mb4EAc7uSwhJPPKDD3H6IccboDlhxt6/4C3HEoeWrb8kog7zugirHZvLJGuOjMm8f0wwuPhxz++7MOofczs0/txz0y8yMTKi2ObNsdDD5Tti00ztf0/PKRdc86tPMdHzC1FQbvAOD/KEA9taYni3q1lyvzbbWbsvcdtw60z2p0O1EAAAh+QQJCgAJACwAAAAAZABkAAAE/zDJSau9OMvVgFGOJo5kaZ6bZ6zGgb5w/DZsLd94Lqm1EerA4KjHcgmPyAlxZUw6KwWEovErLVunggJQWDxNCIBY3BwuyyKDYC0weL+iwniseJuJ6IyCzQbARWFzYgVWZyQOfHx2fxZbgmKLGVd5FwCJbFWMFR2PAAgkkyMFl2yRmhIOnWR3PZQVDKQCCqcYnI+zaYYaDbECprQJC6pcuXgaC70NwBhyqr9Kuhh7pAzLeqrKktEWB72E1hcHw5kVoRhqpH7gGIGPn+fbFKOx5OsTqaqu5hULsKS49i7YEgSwXDwJCGIxeBZQmKpvFXjUqIcoVrY/DDOIc2aBBpFKsf8MYIyCAEGXE44eQZwgrJWFiqRcYTighgGCjBQalNyJQOZLbBc4rABxYd4ldSSEBVi6dOGIAzx5UinRbs7KE91I1QuKgKnXAAWZRY16UoRDQVuTknoXR8BXrwJEjR17AOfGMVdRGF3jRsQBBm+/xvU7d67PBA50TsUhToDNjEoDfxU5QmfhqIsDUugq+e3hCSQv8ywbcFTnt3mPhRZd8vMXBwZOfwWAE0Ni1jsvAmsg2ysD1xqg4u657EDvpQJSw1iwurBuTQCO3zxyW/QywKdpP3FwWfmX6JJ/MxIeNe0X428FPIfDnKd5OAq+1rG2wMH78R6Iat7Pv7///wAGKKD/gAsUaOCBCB444A3MFeDggxBGGGFttCwQGwEYZqjhhhgG0FeDEoYoIoWMLBAAhyimGMACB4joooTA/WFAijRyaMCLOELI34k19khAADkGyZ+PRLYYpIsxwiEAkTXGdaSL/R3AJI1GGPmkg0kyUgCPU3bo3YJPXVlAlmCWaeaZaKap5poZ1OcAiU5wQBx9B9RZJ5xHIDDAngMIQCaDdgZa1zIF8GloX+w5IGig9yURgKGGEhAWdYsK2igSBEAKKZBIsFippctkqimkAlya1KeV4gkEAKOOqp0M9aG6qKpAmNiqpgSwhYKisjJKaxDC3KoppyZ42qudvyKBiLCQOjWCyLHHJvvElszyueIIvPbaqIK0KCAqs5Nyo21tCUq7nAHVDqZBtqkmVW5xAgirbpufwlmuuTcU8C2kSK0LarH3PmPgd7iSGOubKASMQYJPWMhnqRgpbMG7X7CIbwkBC0wxm/xIPPHGHG/g8ccMh8zSyB2XbHLGx4DMMcokI2hyMDCnLHPILJvlspo5t6zymj37fDObQbe5M5o1B3X0mfcC/DPPSyv9NNTcYhw10wOf0PTMMWzN9Qtef6311WIvPHXZ7laN9tgX6xABACH5BAkKAAkALAAAAABkAGQAAAT/MMlJq704y1WUao4mjmRpnpsCrOuBvnD8FiyryHiuS2q9hrugcORjuYbI5KTYUjovh0ajsDgxAcdSAYGgPk1bLhdIumZHCoPaAKh+RQex3E1knjWN9fr2xsvFBSVmJA56enR9Fg1/YogZg2iGa2SJFWGMgXVFd1CSa46VG4xilBiQGgCeBgihGJd/DZo+nJaqBqCtCQujXLQUpxcLtpm5FnG8uEt2GgiqAMUZi6PEF8AVhaq+0A68CMkJ1r+qfNCuvLGmy52qpeUUu7ztEuG6tqzuGa9y6Bb0earf8MEbRauHj3bCVFH7EhDDsVGgaPggRyGNp2d9DhTYqA2DNEac/xYYbFIhoaeOFhwoYGCA34iNMDfKw8BtWrAOABDIOzDOhEgBQIHeGuEgptGGE/RxWWiCp6eZioJKFXBPg0ajMQ8gHTgnhkk9LjMcYDBVqoERV7FmRfsHJRxDGDU4AFB2KgOiatVC3QBzb4kDaQA0CPiz7tS4GvLmRZqrAVnDU91KSKsYplZ8E3hCtstUwwLKlQv4fTN381QFjFOGXgutgGmpAEaLKLpadDEHr4Ey6Azjc+1iCnKH3cEhdDEDplE/oa1WMhK6hg04zwF6Y+ohB+rubuW7bzkEU71BW+BA9hfAOa9jXs++vfv38OPLd7+gvv37+O/Pz/H5gP//AAYYoP96fSxAVwAIJqjggggK0IYuAkYooX8EPrGAAAxmqKEA5E3oIYDm9QGAhiQyiMWHKE73BoYlthiAACmi2J6LNDoQ44QhvmEAjSWedaOE7h3AI4lH2Pijfzkm4tqQCgrA235/1cYalFRWaeWVWGappRP2YcYBCOXkV2EQDRBgJgEMJMmfmGPqUMCZcD5YIJv1FSMAnHAGUJUSdOqXC56ABvCkDH3iV0wAgAKaphCF+pkLAIkmKiehjTrK3Z2R4hnAcCVUamkxBmYKKIwoeFonew4wICqeQ5FgaptPFIDoqmZyOIKprp6aw5IMoITArKvuiUGluX76ggEDJJssRcEYQOvSXSI02ml+MhSg7LVu4SYqtJ7R6ZOYMiB7bbIBaAEsnswOS+0JbMogwLjKcoqBAoGmZuyt7cYAALzJEnCdMGcyAOu3+cLgAL/JIuaqAwOzW7C+CA+gZiXe8kcAwtzCV3EOCESsIsUP5xAAwuW+16cQB0QsrJch68AAwv62t7EQByOssDszC7EvwhMjkTOjF/MrwHo/C9FAxIPOCe4XIwstUMtIpMwvAU+vqyO/JYdp9RsLBH3tzbls/cbR1wbQcBC6hpKdmZNu6fbbcMct99x0axkBACH5BAkKAAkALAAAAABkAGQAAAT/MMlJq704z9NQWVoojmRpSkuHrIhzvnD8HizbyHiuS2qNgLugUORjuYbI5KS4OiqfFUehcACSmC0Tp3GAaqdgK5HpJALOAIXYi5GCwSVsWVNAoxHs0PvdHclHC3Z2a3kUe2+EF39mgmeJhQkHh1N9IYsaB41oj4ULk1OcS2QiCpoAN5AYkp9jRXMWdaahnZ8FrxWXF4GmBakabpOWoxkNpgq+ep+VisMXDqYAy8gWwIecubimeNOYyhnYG9Cz056ftwngEqWavdwhq8HMrhexjWruIrW3PTWEu5rS8DmrRahAEVQVimk6lsfBgYfnMuizkMLHq3+NIjpDcKbdCIcP/0OOm1DuUMAEnlbYupBJE0IRCxAYmDkTwLgFIXM+HBlp0smPskgUoEnUwMs2OnU6uDmJJ0V2IzIVJQpABMikOTVKqLZSRss7VhVMnQoTK9ZZOHfqcMBRgUcMKcZOZRjiqtmQSwXSkztW6wS7dyHqDcd36k+4gAM7VbJAbGGiP2CkDYzX3YHHRBX4DTGZ8mYkDjDXPPwiMdZpMjG/DbLAdM5pjvlGftJZKWq+AD7nML04yOWxq9m0ztlbSIOiDYrvWMBcr4MOyQdLn069uvXr2LNr346Muffv4MMr9xKTgYDz6NOrP89gtvj376kvMLC+vn0D8POLn47Avv/1augn4P94SZj334ECMDCggNMh6OCC+k0HgIP/VQVhfNMdQKF/fVwInnUHGLghe8FxRwJlZpmo4oostujiizDGWI5uSXzoTgMB5BiAATQut980B+go5D155MeNAUIKKcBRNUaITJJQMkCaDANyIwCUUOYmBITcKIAllkRSySU3CzDwJZQClEjChQI1dmaUU1I05mChvZmkTWsueF0BV9qZIwN5OunLUAIYMCWOfgbApJyCpgIAAZBCuk0GgfhpAExGAhnppnHWeealmIaHjwGbRiqAUH1COakGokJRQAADEKDgBQyUGqmaiqDpVHNeNDDAr78SQMijthIQgAmV5oifdQQACyyzoFEUCylda+YForPAEnABscUSWF0B2AKrSwDSghrjBOCGOwAGDUhLQJwmphtuBgJIe+q5EsiLbQYHuLtoi/o6qwGpxQbg7WABi0upu1Wdm/CvISjgbo/fqrtuCOQWCy2MD19Mh7vwYtfxCPVqHOPIIvRb8MkWk8Dtpsdy3DIgGW/a8Isoj1BAqQIcjE/OUZkZAJ4sq4uvDEAfrYW62ioNQ7PYbuy0Cb46K+zUMGgY67ICRQAAIfkECQoACQAsAAAAAGQAZAAABP8wyUmrvTjPU8pZWiiOZGlOXVqAZ+u+J6d2cG3f0pyyeO+Hug7vRywmgiuj8rJwHBxDETIakh2WJudh+ylNSw2EGNGgYi0LrtobNF8K43HhHNKqn6SvaBGPu+kJd2p/FHpAfWOEZ3Z3DiOGGQ6IY4AZaYJbikdtImGTc5UYjHdSnBoHk2KadJiZQKYYfKlXoZattBmQFnCTDbVVrY65sGipCMK/sbd/uhSeiKDJkcHDOm6Sqau1l5huzRLPfbjS060Y36jZ5CLLb8QSspPj68rmFjIzb6m+dAv+/jFambFWLBWyEQ4aKEAQbc+/hyW4NcJgxQw2aBEbANi4EcGIhyD/tSUYteVgFnWPOKoE0DBWSJAfu8GQN+KAgpUqFTh8CTOExC4wLorhp4EPzpU6ffJ86dOBU5GR4DSYh0bj0ZVEiy4NSY/izasrTVrayrWrBAdfwXJUQFUpWYjrjKpVmaTF257JDsxViQAqk7sAfznYu5GtD8DJrM5t2eNtMgRzyywhmxjsMUA8pQ3GaXgb3l8FVjIOFXidgwIN6ppdzbq169ewY8ueTZs04LKtF2g0wLu379+8AUhOcDsz6wUAgCtfDqD4VtYNlksHXsY509XTs/dubh13V+3giXf/11oB+Ok6x5Nn7eC8dGTdYR9wD7xtbYS3qN3fz7+///8ABhhg/xoFiCUgDAUIoKAAABh4oAkHLChhXw++YICEEjIwWoUhYOihAfZxeAEDHnqogF8CIlBiiVmJyMSFK2KooYuWqBgjhg3SKAoAN2J4oo4XzNfjggaQBgABAwSwIYQAMABAiOCQOOSSPywQwABYYukRDAoE4KWXLaKhwJAAAGJAlmiiKMEBX7bpIAWD3VjmImiiGSYJALT5ZZGPSOnhnUQIUGeWW1ZwAAMEBGCAGQbo+SWVFTTgIQNqmlDAoFlSVQABnHIaABVdOhqAACYsMKaCzdFxJaakWhBAp53yCaeoXhZKQhOVnqAAplhSdQCsnQZwQaii5orFAkhiKmshwHbKhNAAtM752pmYEjBQs5xi0ACtAbxJzgG8DpDULtgSkAEDtDLwmqCYCntOuRmwSSuktTQQ7pKbYqtBnqIKYOwPyQ7a6rv6WsKtresAEK63+TYbAgLc/nvDAuEu+wa8RUErqrTkUDuotUBgrEEB3EJ5BsW8InxxwSGgu/E64Lb7iMin0DpwMigPSu8RNO8rqrrrsIsm0FL0bLCjKtfiQMBJatMwsF7oSXRcPArwYx5GnwIjhQI+DSuQWLMM9inYujt2CK8Ca/HZKwcr8YERJrpoVxEAACH5BAkKAAkALAAAAABkAGQAAAT/MMlJq704T3eOW1oojmRpTl16gGfrviendnBt39Kcsnjvh7oO70csJoIro/KyaA5HyGdI5lianE5TtHQoeL3WERbLDUox3a/3EA6NyVCzWK1ua97ZuO5sSdMLfHZ4eUByU39fdneDejOBE4hrihmDTSJbGg6RBZOLjBqYGAubVZ2ilYV7oJumnnighkybj6aVj6EWm2ytrm8ZuBSakbS8tmixFbq8IsYXwDmsy8yofcgSo5Gl0r1jFzIzztFthCXNFaoV2IjEFKMNDbtivlefFlRnwn/xzAUI/v4NSFCT98qFOjrsjvxbiGDfKXNu5r1ApC1TA4YLA06DSEmii3yS/9z0w5iRoC125GAsSFNRFkmMnDaetLTN2UuSCRPMTLnNwcWbDFvKnFlzFFCGSQzupNnqwNGFgG4sLfYUoNAaO1uNPOqwB1FTW19GXcLRTliGY8d5nOSAZIOrVrotc7qwa81aXZLe3cu3r9+/gAMLHky4MOBRCgAoXsy4sWIFaQ2LSey4cmUFOQ0XsMzZcUzJIih3Hq0A9IjRqBWbFoEgdWcEq6e45gw3NgrRswEoqG07mIPfwIMLB967uPHjyJMrD+MAgAADdiet1NtpAYAB2LEDWFbAgHcDCDLfQEAgu/nPkw58X99AvIsDAczLF9BKwfr76Ik4YCC/f4BW9wUIAP9vL1zXX3/0mQJAgAGG10MD5R3YX352NMAggxSecIAAEh5YWivWXShgdG4Y0KF/JI5joYj37WZCARGeiB0BGtXkgH0srufgJTKaB4B7VhywYI7ebScChz0ywJt1ARAgQIYaJuaiBt0RaQCUFMQoYQBYXiMAAWCCWaMLCAhgppld6oQAkbCFEJ+EBLQZAgBh1gnkEWfmSWACN7IoZwYG9vfjCA7UWWeaGSiQ55lGXjJkgIgu8GZ2Auw5AQOGhjkmCgYEIMCgFji3qJkpJiMgSgA0+eSLmYbZVQEBxBqrAFKUOepzV6zpHWZtNNkqAxcIIKusjU6wwK1mbsrMB3aQ1yrrAULBN+ysF9g6KgN3hiHps8VCMq2sTDCA7Id/0dlqAGfA+u1/FxSAbKV/FfrsnxSo+20GBiDb7V1fnpuBvdP+8i6ik8D4LIkAD6uBqNf25WumwP67LruivKssLwo8Cy2VE4fQwLvZeqXxvsl0HIK4t5K7jAHPohtCwuC+/K6lSiyg8cUlrztCvilLI2+mCb5s8hTIGiCNza2WKgHMsZKg6KhGS4OpoVGLwDTFbqCcJ86KbBsmrSRcXYK7eVZ9tAIMMECv0DpzAQADBnAtmdjLvTh03VCsGzTeIwg7Lcl8Y5Aw2IGToJ6noEoTAQAh+QQJCgAJACwAAAAAZABkAAAE/zDJSau9OM/Fl/5gKI4k1XVlqq7qebJwLEsuOt94WHN571c7z2+I4ZWCR4dDSBTVSMiR40A9OJrOZ1YbmlapV6wmqts5v1/xmPxha7zog3ptBrmL8eo8E2TSXSF5YHt8dxaGFXBxhIV1fy8fggd+jECIG44YimiVjVxFmYeSlJ0mlwmnm1VhpRd9pJifQKOtnoCgshSSrLWuiIiqer22kIehNLTDxDaWuQnBVsqPxc3MJslnBQW8WJfU13ncYwfa5XJqp22CUuXt23PHJHmwFg7u93u3LAto4qL3+AjRS7HAy8AJ5AC6Oyfthz2F9w42XLEAIkCJE48ktGguY46HHP+1TfKIo2JIbRhJyjvpTyWMjQoZusQBc2HKmUcUtsQpA6S2nTxn8LNyM6jRo0iTKl169ECDp1CjSn0qk+mFAgQGaN3KtStXAg0m8muAoKzZs2jLNjh3wKvbt1oLSFtANq1duw0WCIDLl2sAaQXuCk7btq/hAdIGKzbbIOthuAQSL15s4DFcBoAnDy6wwLHlr0W7aRbsYQEDz48JMAgtxsFotA2AWi2opLbt20pYW93Nu7fv38ApOFDAwEBVRgVHVloAgIBz5wBKHQBAHUBeQg0CPN8ul5GD6uC7YzkgYLt5zIwQgAev4HhJA+bjC6i0vj4C2SoUxN9voJKC+vVdN0P/AdrtF597WBQAIIDireBAeQbGh0AnC6i34HrttQBfhOYJgF8TCl64HgKhEcjhdgE02EqFIq6nYgYHnLidAhkN12J1E4JwmowGHLSAAgIEwACC8iCgwH2R/HcjkRMUGKEATErAQABUUvkiCQ0YoKWWV5rQwI1hfeBkfAGE+YECVaapmwQObOkmRixeaGYG+u0HQEoOpJlmlyBk6aaWNAaiZH1RogLhcwx8KIEBelZ55XQCMKAALAj8uWWhE4TInhNoCokpQo1WKQ55ApQqQI8W+GlpdCPQVZ2ATQQZan8WMGCqqTmaYOmWfOKiRnahBjDqraaiV4Gqlq4pxgLBBhBo0wWkEjvfIbtqmetEAAQrACzREotBAdUaoOgeeQY7py7SlpoBANU+Kw2joRprQbe3ZtBmtZ+qQWCwRNJrqgaV7sqqMrI2SisG/qrLR7i97oFAs0AlPG0G4FarbEnNunuBxCCwu+u1nWQb6raRpDsxjOGO6wOzwTacAMcgKFAtyISU26i8MJrcRbUDL8dvIDqHEPCfPVcCb5pF55yuE7u63MSDaa4mAsyBED1MhVqeW/LSUiipNVJUBwdC2GJrkDDOZWdgK7E0p70xsVK7PTYAkU7aSwQAIfkECQoACQAsAAAAAGQAZAAABP8wyUmrvTjTxbX/YCiOG2eSaKqqZru+cCy1rmzfIH3ifF/qviBP1xnVhMgZ0UhLJokLEdQpnIas1B7WA41mtctP1/vFbTPj8jCsSavNbHT3DQe25/Tb2YLP2/Y/cX4wgEqFgymHbogxhYuMhIITj1UHZEGSCZQ+DgIDnwyXa0cVfVcOBw6iaASfrgMASDt8ph+oB7ipIACvrwQFeYd8ucSWH569rwIHb8KTxcUOx8nJBquydm230MQfCtTJBApqpBjb3LnSXAHgyQHAkM/o0Nd8DO3JAuqIC/Pc9RgKsMP3CgBAJwvO+dOVAkErgp8CHKy0MN1ELrwgwmpWMdfFEJ3/IBJ4oxDdRxIC8Y1UUzIaEgUP3ZGcpwqhAWrwyvT7V+YAsk8I8ig82eMAggZEfSSsGa+p06dQo0qdSvXLgQJYs2rdipVZ1RQCCYgdS7Ys2XdPr3Jdu9XrAbNw44r1ComtXa4JBMjdS5ZBPLV3A7/lS3glo8CIsQYovDdAvMSIDTCWa+AvZLuWFk8uKzHegstsoywwoHlyAGtOP4PWmvTrpDHOXMueTbu27du2HSgwAICuUKbkFAQYPnwcHQcIkiMo0BpGAwHEo/vOgly58ulBDjCIzr2ymgLWrTfYpwUA9/N+1YRfP34IgvPwY6lpsH49cxsFoMM/j92J0frr9TeC/3b7wddAHvQBGF57KCxgXoHdkffGfwpad58IAkEYnQA5DfJZheF1qMEBGkYXlFMOJAjiUSCQVqJBbSDAgAAGCDhCikdJaAGFINo4gX4FMuCjJgYIYKSRIqIEwJJLDtnPiklaAOR5HIKAwJFYNieBA0x2edGHCkZZgXDwIfBRJ1geOWQGBXTJ5Im2qBjemgtsFx2MIQCQ5pFR6maAAUhd0ICbTOqYAY/JHZjDlTSuSYFPexqp4wF/VoonBW0SCoBxV4CX3IVIFBmpfBVUaqqiG2jaZINZPBepAKs4YKqlF2RKqAJaIjRjpHA+OmulGCigKqpOKfBqKBdQ+qt3O6p6ab48aEYqprK/ZoCAqr1ComekzO64bLcVcKmqo1nk96qN1M6qwaCacsrIrnu66+2ybTgr5nyvwjritx7YSmiueuRLbLL8eiCspgO/YWyk6e1LrwcHOGtoFgvke+8E6Zpq5bB+RJsmqQ5XK4aq8ur06sQVZAwsCP6+Oci2WJaMgcp/XnFwlxfbhCW4IasbQsRdZkvHZ5vmnHLBIDWgwHK4SUAzz00PiHTUKMj6K8hUk7Bswln/POuzXd+4GwCBDhIBACH5BAUKAAkALAAAAABkAGQAAAT/MMlJq7046827/2AojmRpnmiqrmzrvnAstwsQEMIxY8veLYGBUFjwSRbIpDEDGA4JPV9yurwEnUKDdKqsVgjYoU7GpXopgrAwMCt3z5KCWtiIuZHwSlpNsN/zFA5zAwAvd1GAE01ziCuHiRQLYGoMNH+QFAiDYymHjZgJV2FsKo+gFAeDCJ2XpxQMc1Aopq4TgnOFJrRtDp8ci2oOJZ47CwwEyAa+GZK4w60fZhxAyNUECh8NcwLPZSFuHQrW1gFFHaJOlSTQG8Qbx+PWAsIbqWHmI+A/nssV8PHWlG1QgEWLLi77+HFAADBegFUaDjAIIADfwX4V+EljdqPhuHK1/xJo3KhhgQGP8RjQwzTyjYcDAlCOA4BxS8uaGhp0lIkDJ4ybeHQB4Iksl5ebKxz880iqCtIWBXY2PDNSBgKp8qi6azM0nsUlu3YotVYHjr4zDhoU8NkmaMi3cOPKnUu3rt16BfLq3cs3L6e7HgoICEC4sOHDhiuGdHCgsePHkB/TO4C4smXCfyFF3sy5cQIDl0MbNoiJcefTjh2IXk34FOrXjQezvswNFOzXNmZbNgrJ9O3NvWTrTsxWym/OPWoIny2AZq0FxyEXB3wEqFvq2LNr3869e8gFCAAoyEy1l1kEAtKnh4h274HpKQowUE+ffLG+Bey7OGCAvn/eRhyAX/9eK7mwgAL+JUjaEgPuBZ8HDSQoITZeNOjegxnIJ6GEBRrhgIV7dSiCAwBsKOFXDIIYYj4ImvifiFV8qKJf8EnkIn0G6HeUgDPm99KN6jFQlisL9OjjL0AKoEBNCzQAgAHjoSDjWhtMCSKM/twIAJYUPGnAlzmacAACZJKp4wQ8WnimBP1tyMCaEjQA5pwYHlHmnT5Bp+ZCGw7ZzpxzwonBmHeSiSIPDXI5gUn+LfmBAoCCaZ8D4SlApQUFFFqmohVYqZcHTRrAgAKcVsBfpF+KeAAArLLqqKmakulnB2kKioKXkVJYgQKttooieLEiYGskRhSA6pe+kNirqxcQGmvRncUca8CsEqy6LKsYNBDsoZggIO0y1l6LAaXBQhuDA9LqF+6yGWgbK7eAQIoqgKhciy0PwSJQ6hKnosrlur1qkGms1AKCK6DsNWsvvZHkO6wMxh5bE8Ct1pOvuaVIC2+1C3PgrqYb++DtvBxQfK8G5D4LiEnHwmkyw5huCwi6qOoaUcfTBFuwESxHuu/LLxGciLxz7mwB0D/E+rCBB9tcD84dpGwoSwOHbCrUPxTQQANLh4S0dyJ8DTYIyi7r9Nge8Lqs1WgfbTbG3qUl3qWARAAAOw==);background-position:50% 90%}#DeferredLoadingText{position:relative;top:60px;font-family:Tahoma,sans-serif;font-size:18px;color:#fff;text-align:cente
}


    </style>
    <script>
        if (window.location.href.indexOf("replayGame.do") != -1)
            document.title = "Pragmatic Replay";
        var gaQueue = [],
            ga = function() {
                gaQueue.push(arguments)
            };

        var URLGameSymbol = "_unknown_game_symbol_from_url_";
        var LoadingStep = 0;

        var UHT_SEND_ERRORS = true;
        var UHT_HAD_ERRORS = false;

        window.onerror = function(messageOrEvent, source, lineno, colno) {

            if (!UHT_SEND_ERRORS)
                return;

            UHT_HAD_ERRORS = true;

            var args = null;

            if (messageOrEvent instanceof Event)
                args = [messageOrEvent["message"], messageOrEvent["fileName"], messageOrEvent["lineNumber"], messageOrEvent["columnNumber"]];
            else
                args = [messageOrEvent, source, lineno, colno];

            args[1] = String(args[1]).split("?").shift().split("/").pop();

            var msg = args[0] + " at " + args[1] + ":" + args[2] + ":" + args[3];
            ga('BehaviourTracker.send', 'event', "uht_errors", msg, URLGameSymbol, 1);

            window.onerror = null;
        };

        window.onbeforeunload = function() {
            var step = LoadingStep.toString() + (LoadingStep + 1).toString();
            var lastStep = LoadingStep.toString();

            if (LoadingStep == 4) {
                step = "PLAYING";
                lastStep = "PLAYING"
            }

            ga('LoadingTracker.send', 'event', "uht_loading", "_CLOSED_error_" + step, URLGameSymbol, UHT_HAD_ERRORS ? 1 : 0);

            if (LoadingStep > 1)
                globalTracking.StopTimerAndSend("uht_loading", "_CLOSED_at_" + lastStep, "LoadingTracker");
            else
            if (GA_timer_load_start != undefined)
                ga('LoadingTracker.send', 'timer', "uht_loading", "_CLOSED_at_1", URLGameSymbol, new Date().getTime() - GA_timer_load_start);

            UHT_SEND_ERRORS = false;

            if (SendTrackingIfQueued != undefined) {
                SendTrackingIfQueued();
                SendTrackingIfQueued();
                SendTrackingIfQueued();
                SendTrackingIfQueued();
            }

            return;
        }


        var game_symbol_from_url = (function() {
            var params = [];
            var urlSplitted = location.href.split("?");
            if (urlSplitted.length > 1) {
                var paramsSplitted = urlSplitted[1].split("&");
                for (var i = 0; i < paramsSplitted.length; ++i) {
                    var paramSplitted = paramsSplitted[i].split("=");
                    params[paramSplitted[0]] = (paramSplitted.length > 1) ? paramSplitted[1] : null;
                }
            }
            return params["symbol"];
        })();

        var game_symbol_from_url_value = game_symbol_from_url;

        if (game_symbol_from_url_value != undefined)
            URLGameSymbol = game_symbol_from_url_value;

        //ga('create', 'UA-83294317-1', {'siteSpeedSampleRate': 100, 'sampleRate': 10});
        ga('create', 'UA-83294317-2', {
            'siteSpeedSampleRate': 10,
            'sampleRate': 5,
            name: "RatingTracker"
        });

        ga('create', 'UA-83294317-3', {
            'siteSpeedSampleRate': 10,
            'sampleRate': 1,
            name: "LoadingTracker"
        });
        ga('create', 'UA-83294317-4', {
            'siteSpeedSampleRate': 10,
            'sampleRate': 1,
            name: "SpinTracker"
        });
        ga('create', 'UA-83294317-5', {
            'siteSpeedSampleRate': 10,
            'sampleRate': 100,
            name: "ServerErrorsTracker"
        });
        ga('create', 'UA-83294317-6', {
            'siteSpeedSampleRate': 10,
            'sampleRate': 5,
            name: "BehaviourTracker"
        });

        ga('LoadingTracker.send', 'event', "uht_loading", "_0_game_icon_clicked", URLGameSymbol, 1);

        function sendGAQueued() {
            var item = gaQueue.shift();
            if (item != undefined)
                ga.apply(window, item);

            if (gaQueue.length > 0)
                setTimeout(sendGAQueued, 1500);
        }

        ! function(r, d) {
            function i(i) {
                for (var e = {}, o = 0; o < i.length; o++) e[i[o].toUpperCase()] = i[o];
                return e
            }

            function n(i, e) {
                return typeof i == w && -1 !== I(e).indexOf(I(i))
            }

            function t(i, e) {
                if (typeof i == w) return i = i.replace(/^\s\s*/, "").replace(/\s\s*$/, ""), typeof e == b ? i : i.substring(0, 255)
            }

            function s(i, e) {
                for (var o, a, r, n, t, s = 0; s < e.length && !n;) {
                    for (var b = e[s], w = e[s + 1], l = o = 0; l < b.length && !n;)
                        if (n = b[l++].exec(i))
                            for (a = 0; a < w.length; a++) t = n[++o], typeof(r = w[a]) == c && 0 < r.length ? 2 === r.length ? typeof r[1] == u ? this[r[0]] = r[1].call(this,
                                t) : this[r[0]] = r[1] : 3 === r.length ? typeof r[1] != u || r[1].exec && r[1].test ? this[r[0]] = t ? t.replace(r[1], r[2]) : d : this[r[0]] = t ? r[1].call(this, t, r[2]) : d : 4 === r.length && (this[r[0]] = t ? r[3].call(this, t.replace(r[1], r[2])) : d) : this[r] = t || d;
                    s += 2
                }
            }

            function e(i, e) {
                for (var o in e)
                    if (typeof e[o] == c && 0 < e[o].length)
                        for (var a = 0; a < e[o].length; a++) {
                            if (n(e[o][a], i)) return "?" === o ? d : o
                        } else if (n(e[o], i)) return "?" === o ? d : o;
                return i
            }
            var u = "function",
                b = "undefined",
                c = "object",
                w = "string",
                l = "model",
                p = "name",
                m = "type",
                f = "vendor",
                h = "version",
                g = "architecture",
                o = "console",
                a = "mobile",
                v = "tablet",
                x = "smarttv",
                k = "wearable",
                y = "embedded",
                _ = "Amazon",
                S = "Apple",
                T = "ASUS",
                q = "BlackBerry",
                z = "Browser",
                N = "Chrome",
                A = "Firefox",
                C = "Google",
                E = "Huawei",
                O = "LG",
                U = "Microsoft",
                j = "Motorola",
                R = "Opera",
                M = "Samsung",
                P = "Sony",
                V = "Xiaomi",
                B = "Zebra",
                D = "Facebook",
                I = function(i) {
                    return i.toLowerCase()
                },
                W = {
                    ME: "4.90",
                    "NT 3.11": "NT3.51",
                    "NT 4.0": "NT4.0",
                    2E3: "NT 5.0",
                    XP: ["NT 5.1", "NT 5.2"],
                    Vista: "NT 6.0",
                    7: "NT 6.1",
                    8: "NT 6.2",
                    "8.1": "NT 6.3",
                    10: ["NT 6.4", "NT 10.0"],
                    RT: "ARM"
                },
                F = {
                    browser: [
                        [/\b(?:crmo|crios)\/([\w\.]+)/i],
                        [h, [p, "Chrome"]],
                        [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                        [h, [p, "Edge"]],
                        [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i],
                        [p, h],
                        [/opios[\/ ]+([\w\.]+)/i],
                        [h, [p, R + " Mini"]],
                        [/\bopr\/([\w\.]+)/i],
                        [h, [p, R]],
                        [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i, /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i, /(ba?idubrowser)[\/ ]?([\w\.]+)/i, /(?:ms|\()(ie) ([\w\.]+)/i,
                            /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale|qqbrowserlite|qq)\/([-\w\.]+)/i, /(weibo)__([\d\.]+)/i
                        ],
                        [p, h],
                        [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i],
                        [h, [p, "UC" + z]],
                        [/\bqbcore\/([\w\.]+)/i],
                        [h, [p, "WeChat(Win) Desktop"]],
                        [/micromessenger\/([\w\.]+)/i],
                        [h, [p, "WeChat"]],
                        [/konqueror\/([\w\.]+)/i],
                        [h, [p, "Konqueror"]],
                        [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i],
                        [h, [p, "IE"]],
                        [/yabrowser\/([\w\.]+)/i],
                        [h, [p, "Yandex"]],
                        [/(avast|avg)\/([\w\.]+)/i],
                        [
                            [p, /(.+)/, "$1 Secure " + z], h
                        ],
                        [/\bfocus\/([\w\.]+)/i],
                        [h, [p, A + " Focus"]],
                        [/\bopt\/([\w\.]+)/i],
                        [h, [p, R + " Touch"]],
                        [/coc_coc\w+\/([\w\.]+)/i],
                        [h, [p, "Coc Coc"]],
                        [/dolfin\/([\w\.]+)/i],
                        [h, [p, "Dolphin"]],
                        [/coast\/([\w\.]+)/i],
                        [h, [p, R + " Coast"]],
                        [/miuibrowser\/([\w\.]+)/i],
                        [h, [p, "MIUI " + z]],
                        [/fxios\/([-\w\.]+)/i],
                        [h, [p, A]],
                        [/\bqihu|(qi?ho?o?|360)browser/i],
                        [
                            [p, "360 " + z]
                        ],
                        [/(oculus|samsung|sailfish)browser\/([\w\.]+)/i],
                        [
                            [p, /(.+)/, "$1 " + z], h
                        ],
                        [/(comodo_dragon)\/([\w\.]+)/i],
                        [
                            [p, /_/g, " "], h
                        ],
                        [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i],
                        [p, h],
                        [/(metasr)[\/ ]?([\w\.]+)/i, /(lbbrowser)/i],
                        [p],
                        [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i],
                        [
                            [p, D], h
                        ],
                        [/safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(chromium|instagram)[\/ ]([-\w\.]+)/i],
                        [p, h],
                        [/\bgsa\/([\w\.]+) .*safari\//i],
                        [h, [p, "GSA"]],
                        [/headlesschrome(?:\/([\w\.]+)| )/i],
                        [h, [p, N + " Headless"]],
                        [/ wv\).+(chrome)\/([\w\.]+)/i],
                        [
                            [p, N + " WebView"], h
                        ],
                        [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i],
                        [h, [p, "Android " + z]],
                        [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i],
                        [p, h],
                        [/version\/([\w\.]+) .*mobile\/\w+ (safari)/i],
                        [h, [p, "Mobile Safari"]],
                        [/version\/([\w\.]+) .*(mobile ?safari|safari)/i],
                        [h, p],
                        [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i],
                        [p, [h, e, {
                            "1.0": "/8",
                            "1.2": "/1",
                            "1.3": "/3",
                            "2.0": "/412",
                            "2.0.2": "/416",
                            "2.0.3": "/417",
                            "2.0.4": "/419",
                            "?": "/"
                        }]],
                        [/(webkit|khtml)\/([\w\.]+)/i],
                        [p, h],
                        [/(navigator|netscape\d?)\/([-\w\.]+)/i],
                        [
                            [p, "Netscape"], h
                        ],
                        [/mobile vr; rv:([\w\.]+)\).+firefox/i],
                        [h, [p, A + " Reality"]],
                        [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i,
                            /(links) \(([\w\.]+)/i
                        ],
                        [p, h]
                    ],
                    cpu: [
                        [/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i],
                        [
                            [g, "amd64"]
                        ],
                        [/(ia32(?=;))/i],
                        [
                            [g, I]
                        ],
                        [/((?:i[346]|x)86)[;\)]/i],
                        [
                            [g, "ia32"]
                        ],
                        [/\b(aarch64|arm(v?8e?l?|_?64))\b/i],
                        [
                            [g, "arm64"]
                        ],
                        [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                        [
                            [g, "armhf"]
                        ],
                        [/windows (ce|mobile); ppc;/i],
                        [
                            [g, "arm"]
                        ],
                        [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i],
                        [
                            [g, /ower/, "", I]
                        ],
                        [/(sun4\w)[;\)]/i],
                        [
                            [g, "sparc"]
                        ],
                        [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                        [
                            [g, I]
                        ]
                    ],
                    device: [
                        [/\b(sch-i[89]0\d|shw-m380s|sm-[pt]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i],
                        [l, [f, M],
                            [m, v]
                        ],
                        [/\b((?:s[cgp]h|gt|sm)-\w+|galaxy nexus)/i, /samsung[- ]([-\w]+)/i, /sec-(sgh\w+)/i],
                        [l, [f, M],
                            [m, a]
                        ],
                        [/\((ip(?:hone|od)[\w ]*);/i],
                        [l, [f, S],
                            [m, a]
                        ],
                        [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                        [l, [f, S],
                            [m, v]
                        ],
                        [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i],
                        [l, [f, E],
                            [m, v]
                        ],
                        [/(?:huawei|honor)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}-[atu]?[ln][01259x][012359][an]?)\b(?!.+d\/s)/i],
                        [l, [f, E],
                            [m, a]
                        ],
                        [/\b(poco[\w ]+)(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i],
                        [
                            [l, /_/g, " "],
                            [f, V],
                            [m, a]
                        ],
                        [/\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i],
                        [
                            [l, /_/g, " "],
                            [f, V],
                            [m, v]
                        ],
                        [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007|a101op)\b/i],
                        [l, [f, "OPPO"],
                            [m, a]
                        ],
                        [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i],
                        [l, [f, "Vivo"],
                            [m, a]
                        ],
                        [/\b(rmx[12]\d{3})(?: bui|;|\))/i],
                        [l, [f, "Realme"],
                            [m, a]
                        ],
                        [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i],
                        [l, [f, j],
                            [m, a]
                        ],
                        [/\b(mz60\d|xoom[2 ]{0,2}) build\//i],
                        [l, [f, j],
                            [m, v]
                        ],
                        [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i],
                        [l, [f, O],
                            [m, v]
                        ],
                        [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i,
                            /\blg-?([\d\w]+) bui/i
                        ],
                        [l, [f, O],
                            [m, a]
                        ],
                        [/(ideatab[-\w ]+)/i, /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i],
                        [l, [f, "Lenovo"],
                            [m, v]
                        ],
                        [/(?:maemo|nokia).*(n900|lumia \d+)/i, /nokia[-_ ]?([-\w\.]*)/i],
                        [
                            [l, /_/g, " "],
                            [f, "Nokia"],
                            [m, a]
                        ],
                        [/(pixel c)\b/i],
                        [l, [f, C],
                            [m, v]
                        ],
                        [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i],
                        [l, [f, C],
                            [m, a]
                        ],
                        [/droid.+ ([c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                        [l, [f, P],
                            [m, a]
                        ],
                        [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i],
                        [
                            [l, "Xperia Tablet"],
                            [f, P],
                            [m, v]
                        ],
                        [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i],
                        [l, [f, "OnePlus"],
                            [m, a]
                        ],
                        [/(alexa)webm/i, /(kf[a-z]{2}wi)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i],
                        [l, [f, _],
                            [m, v]
                        ],
                        [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i],
                        [
                            [l, /(.+)/g, "Fire Phone $1"],
                            [f, _],
                            [m, a]
                        ],
                        [/(playbook);[-\w\),; ]+(rim)/i],
                        [l, f, [m, v]],
                        [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i],
                        [l, [f, q],
                            [m, a]
                        ],
                        [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i],
                        [l, [f, T],
                            [m, v]
                        ],
                        [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i],
                        [l, [f, T],
                            [m, a]
                        ],
                        [/(nexus 9)/i],
                        [l, [f, "HTC"],
                            [m, v]
                        ],
                        [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic|sony)[-_ ]?([-\w]*)/i],
                        [f, [l, /_/g, " "],
                            [m, a]
                        ],
                        [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i],
                        [l, [f, "Acer"],
                            [m, v]
                        ],
                        [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i],
                        [l, [f, "Meizu"],
                            [m, a]
                        ],
                        [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i],
                        [l, [f, "Sharp"],
                            [m, a]
                        ],
                        [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i,
                            /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i
                        ],
                        [f, l, [m, a]],
                        [/(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i],
                        [f, l, [m, v]],
                        [/(surface duo)/i],
                        [l, [f, U],
                            [m, v]
                        ],
                        [/droid [\d\.]+; (fp\du?)(?: b|\))/i],
                        [l, [f, "Fairphone"],
                            [m, a]
                        ],
                        [/(u304aa)/i],
                        [l, [f, "AT&T"],
                            [m, a]
                        ],
                        [/\bsie-(\w*)/i],
                        [l, [f, "Siemens"],
                            [m, a]
                        ],
                        [/\b(rct\w+) b/i],
                        [l, [f, "RCA"],
                            [m, v]
                        ],
                        [/\b(venue[\d ]{2,7}) b/i],
                        [l, [f, "Dell"],
                            [m, v]
                        ],
                        [/\b(q(?:mv|ta)\w+) b/i],
                        [l, [f, "Verizon"],
                            [m, v]
                        ],
                        [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i],
                        [l, [f, "Barnes & Noble"],
                            [m, v]
                        ],
                        [/\b(tm\d{3}\w+) b/i],
                        [l, [f, "NuVision"],
                            [m, v]
                        ],
                        [/\b(k88) b/i],
                        [l, [f, "ZTE"],
                            [m, v]
                        ],
                        [/\b(nx\d{3}j) b/i],
                        [l, [f, "ZTE"],
                            [m, a]
                        ],
                        [/\b(gen\d{3}) b.+49h/i],
                        [l, [f, "Swiss"],
                            [m, a]
                        ],
                        [/\b(zur\d{3}) b/i],
                        [l, [f, "Swiss"],
                            [m, v]
                        ],
                        [/\b((zeki)?tb.*\b) b/i],
                        [l, [f, "Zeki"],
                            [m, v]
                        ],
                        [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i],
                        [
                            [f, "Dragon Touch"], l, [m, v]
                        ],
                        [/\b(ns-?\w{0,9}) b/i],
                        [l, [f, "Insignia"],
                            [m, v]
                        ],
                        [/\b((nxa|next)-?\w{0,9}) b/i],
                        [l, [f, "NextBook"],
                            [m, v]
                        ],
                        [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i],
                        [
                            [f, "Voice"], l, [m, a]
                        ],
                        [/\b(lvtel\-)?(v1[12]) b/i],
                        [
                            [f, "LvTel"], l, [m, a]
                        ],
                        [/\b(ph-1) /i],
                        [l, [f, "Essential"],
                            [m, a]
                        ],
                        [/\b(v(100md|700na|7011|917g).*\b) b/i],
                        [l, [f, "Envizen"],
                            [m, v]
                        ],
                        [/\b(trio[-\w\. ]+) b/i],
                        [l, [f, "MachSpeed"],
                            [m, v]
                        ],
                        [/\btu_(1491) b/i],
                        [l, [f, "Rotor"],
                            [m, v]
                        ],
                        [/(shield[\w ]+) b/i],
                        [l, [f, "Nvidia"],
                            [m, v]
                        ],
                        [/(sprint) (\w+)/i],
                        [f, l, [m, a]],
                        [/(kin\.[onetw]{3})/i],
                        [
                            [l, /\./g, " "],
                            [f, U],
                            [m, a]
                        ],
                        [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                        [l, [f, B],
                            [m, v]
                        ],
                        [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i],
                        [l, [f, B],
                            [m, a]
                        ],
                        [/(ouya)/i, /(nintendo) ([wids3utch]+)/i],
                        [f, l, [m, o]],
                        [/droid.+; (shield) bui/i],
                        [l, [f, "Nvidia"],
                            [m, o]
                        ],
                        [/(playstation [345portablevi]+)/i],
                        [l, [f, P],
                            [m, o]
                        ],
                        [/\b(xbox(?: one)?(?!; xbox))[\); ]/i],
                        [l, [f, U],
                            [m, o]
                        ],
                        [/smart-tv.+(samsung)/i],
                        [f, [m, x]],
                        [/hbbtv.+maple;(\d+)/i],
                        [
                            [l, /^/, "SmartTV"],
                            [f, M],
                            [m, x]
                        ],
                        [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i],
                        [
                            [f, O],
                            [m, x]
                        ],
                        [/(apple) ?tv/i],
                        [f, [l, S + " TV"],
                            [m, x]
                        ],
                        [/crkey/i],
                        [
                            [l, N + "cast"],
                            [f, C],
                            [m, x]
                        ],
                        [/droid.+aft(\w)( bui|\))/i],
                        [l, [f, _],
                            [m, x]
                        ],
                        [/\(dtv[\);].+(aquos)/i],
                        [l, [f, "Sharp"],
                            [m, x]
                        ],
                        [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w ]*; *(\w[^;]*);([^;]*)/i],
                        [
                            [f, t],
                            [l, t],
                            [m, x]
                        ],
                        [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i],
                        [
                            [m, x]
                        ],
                        [/((pebble))app/i],
                        [f, l, [m, k]],
                        [/droid.+; (glass) \d/i],
                        [l, [f, C],
                            [m, k]
                        ],
                        [/droid.+; (wt63?0{2,3})\)/i],
                        [l, [f, B],
                            [m, k]
                        ],
                        [/(quest( 2)?)/i],
                        [l, [f, D],
                            [m, k]
                        ],
                        [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i],
                        [f, [m, y]],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i],
                        [l, [m, a]],
                        [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i],
                        [l, [m, v]],
                        [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i],
                        [
                            [m, v]
                        ],
                        [/(phone|mobile(?:[;\/]| safari)|pda(?=.+windows ce))/i],
                        [
                            [m, a]
                        ],
                        [/(android[-\w\. ]{0,9});.+buil/i],
                        [l, [f, "Generic"]]
                    ],
                    engine: [
                        [/windows.+ edge\/([\w\.]+)/i],
                        [h, [p, "EdgeHTML"]],
                        [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                        [h, [p, "Blink"]],
                        [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i],
                        [p, h],
                        [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [h, p]
                    ],
                    os: [
                        [/microsoft (windows) (vista|xp)/i],
                        [p, h],
                        [/(windows) nt 6\.2; (arm)/i, /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i,
                            /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i
                        ],
                        [p, [h, e, W]],
                        [/(win(?=3|9|n)|win 9x )([nt\d\.]+)/i],
                        [
                            [p, "Windows"],
                            [h, e, W]
                        ],
                        [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /cfnetwork\/.+darwin/i],
                        [
                            [h, /_/g, "."],
                            [p, "iOS"]
                        ],
                        [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i],
                        [
                            [p, "Mac OS"],
                            [h, /_/g, "."]
                        ],
                        [/droid ([\w\.]+)\b.+(android[- ]x86)/i],
                        [h, p],
                        [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i,
                            /\((series40);/i
                        ],
                        [p, h],
                        [/\(bb(10);/i],
                        [h, [p, q]],
                        [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i],
                        [h, [p, "Symbian"]],
                        [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i],
                        [h, [p, A + " OS"]],
                        [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                        [h, [p, "webOS"]],
                        [/crkey\/([\d\.]+)/i],
                        [h, [p, N + "cast"]],
                        [/(cros) [\w]+ ([\w\.]+\w)/i],
                        [
                            [p, "Chromium OS"], h
                        ],
                        [/(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i,
                            /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i
                        ],
                        [p, h],
                        [/(sunos) ?([\w\.\d]*)/i],
                        [
                            [p, "Solaris"], h
                        ],
                        [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux)/i, /(unix) ?([\w\.]*)/i],
                        [p, h]
                    ]
                },
                G = function(i, e) {
                    if (typeof i == c && (e = i, i = d), !(this instanceof G)) return (new G(i, e)).getResult();
                    var o = i || (typeof r != b && r.navigator && r.navigator.userAgent ? r.navigator.userAgent : ""),
                        a = e ? function(i, e) {
                            var o, a = {};
                            for (o in i) e[o] && e[o].length % 2 == 0 ? a[o] = e[o].concat(i[o]) : a[o] = i[o];
                            return a
                        }(F, e) : F;
                    return this.getBrowser =
                        function() {
                            var i, e = {};
                            return e[p] = d, e[h] = d, s.call(e, o, a.browser), e.major = typeof(i = e.version) == w ? i.replace(/[^\d\.]/g, "").split(".")[0] : d, e
                        }, this.getCPU = function() {
                            var i = {};
                            return i[g] = d, s.call(i, o, a.cpu), i
                        }, this.getDevice = function() {
                            var i = {};
                            return i[f] = d, i[l] = d, i[m] = d, s.call(i, o, a.device), i
                        }, this.getEngine = function() {
                            var i = {};
                            return i[p] = d, i[h] = d, s.call(i, o, a.engine), i
                        }, this.getOS = function() {
                            var i = {};
                            return i[p] = d, i[h] = d, s.call(i, o, a.os), i
                        }, this.getResult = function() {
                            return {
                                ua: this.getUA(),
                                browser: this.getBrowser(),
                                engine: this.getEngine(),
                                os: this.getOS(),
                                device: this.getDevice(),
                                cpu: this.getCPU()
                            }
                        }, this.getUA = function() {
                            return o
                        }, this.setUA = function(i) {
                            return o = typeof i == w && 255 < i.length ? t(i, 255) : i, this
                        }, this.setUA(o), this
                };
            G.VERSION = "0.7.31", G.BROWSER = i([p, h, "major"]), G.CPU = i([g]), G.DEVICE = i([l, f, m, o, a, x, v, k, y]), G.ENGINE = G.OS = i([p, h]), typeof exports != b ? (typeof module != b && module.exports && (exports = module.exports = G), exports.UAParser2 = G) : typeof define == u && define.amd ? define(function() {
                return G
            }) : typeof r != b && (r.UAParser2 =
                G);
            var L, Z = typeof r != b && (r.jQuery || r.Zepto);
            Z && !Z.ua && (L = new G, Z.ua = L.getResult(), Z.ua.get = function() {
                return L.getUA()
            }, Z.ua.set = function(i) {
                L.setUA(i);
                var e, o = L.getResult();
                for (e in o) Z.ua[e] = o[e]
            })
        }("object" == typeof window ? window : this);
        var goog = {
            require: function() {},
            provide: function() {}
        };
        var UHT_ALL = false;
        var UHT_CONFIG = {
            GAME_URL: "",
            GAME_URL_ALTERNATIVE: "",
            LANGUAGE: "en",
            SYMBOL: "symbol",
            MINI_MODE: false,
            LOBBY_LAUNCHED: false
        };
        var UHT_DEVICE_TYPE = {
            MOBILE: false,
            DESKTOP: false
        };
        var UHT_FRAME = false;
        var UHT_LOW_END_DEVICE = false;
        var currentDatapathRetries = 0;
        var retriesBeforeAlternativeDatapath = 5;
        var LowEndDeviceIdentifiers = ["S III", "GT-I9300", "iPhone 5", "iPhone 5C", "iPhone 5S", "iPhone 6", "iPhone 6 Plus"];
        var UHTConsole = {};
        var UHT_UA_INFO = (new UAParser2).getResult();
        window.console = window.console || function() {
            var c = {};
            c.log = c.warn = c.debug = c.info = c.error = c.time = c.dir = c.profile = c.clear = c.exception = c.trace = c.assert = function() {};
            return c
        }();
        UHTConsole.Message = function(type, args) {
            this.type = type;
            this.args = args
        };
        UHTConsole.allowToWrite = false;
        UHTConsole.methods = ["log", "info", "warn", "error"];
        UHTConsole.source = {};
        UHTConsole.replacement = {};
        UHTConsole.messages = [];
        UHTConsole.wasAllowedToWrite = false;
        UHTConsole.redirectOutput = false;
        UHTConsole.logFilename = null;
        UHTConsole.GetReplacement = function(methodIdx) {
            return function() {
                var stringARGS = [];
                for (var i = 0; i < arguments.length; i++)
                    if (arguments[i] != null) stringARGS.push(arguments[i].toString());
                if (UHTConsole.redirectOutput) {
                    var args = [];
                    args.push(["g", UHT_CONFIG.SYMBOL].join("="));
                    args.push(["f", UHTConsole.logFilename].join("="));
                    args.push(["d", (new Date).getTime()].join("="));
                    args.push([UHTConsole.methods[methodIdx], stringARGS.join(",")].join("="));
                    (new Image).src = "/console.php?" + args.join("&")
                } else UHTConsole.messages.push(new UHTConsole.Message(UHTConsole.methods[methodIdx],
                    stringARGS));
                if (UHTConsole.messages.length > 512) UHTConsole.messages.splice(0, 128)
            }
        };
        UHTConsole.AllowToWrite = function(allowToWrite) {
            if (UHTConsole.redirectOutput) {
                UHTConsole.wasAllowedToWrite = allowToWrite;
                return
            }
            for (var i = 0; i < UHTConsole.methods.length; ++i) {
                var name = UHTConsole.methods[i];
                if (UHTConsole.source[name] == null) UHTConsole.source[name] = console[name];
                if (!allowToWrite)
                    if (UHTConsole.replacement[name] == null) UHTConsole.replacement[name] = UHTConsole.GetReplacement(i);
                console[name] = allowToWrite ? UHTConsole.source[name] : UHTConsole.replacement[name]
            }
            if (allowToWrite && !UHTConsole.allowToWrite) {
                for (var i =
                        0; i < UHTConsole.messages.length; ++i) console[UHTConsole.messages[i].type](UHTConsole.messages[i].args[0]);
                UHTConsole.messages = []
            }
            UHTConsole.allowToWrite = allowToWrite
        };
        UHTConsole.RedirectOutput = function(redirectOutput) {
            if (UHTConsole.redirectOutput == Boolean(redirectOutput)) return;
            if (redirectOutput) {
                if (UHTConsole.logFilename == null) UHTConsole.logFilename = UHTConsole.FormatDate(new Date);
                UHTConsole.wasAllowedToWrite = UHTConsole.allowToWrite;
                UHTConsole.AllowToWrite(false);
                UHTConsole.redirectOutput = redirectOutput;
                for (var i = 0; i < UHTConsole.messages.length; ++i) console[UHTConsole.messages[i].type](UHTConsole.messages[i].args[0]);
                UHTConsole.messages = []
            } else {
                UHTConsole.redirectOutput =
                    redirectOutput;
                UHTConsole.AllowToWrite(UHTConsole.wasAllowedToWrite)
            }
        };
        UHTConsole.FormatDate = function(d) {
            var date = d.toJSON().split("T")[0];
            var time = d.toTimeString().split(" ")[0].replace(/:/g, "-");
            return [date, time].join("_")
        };
        var Loader = {};
        Loader.WURFLProcessed = false;
        Loader.statisticsURL = null;
        Loader.statistics = null;
        Loader.LoadScript = function(url, loadCallback, errorCallback) {
            var script = document.createElement("script");
            script.src = url;
            if (loadCallback != undefined) script.onload = loadCallback;
            if (errorCallback != undefined) {
                script.onabort = errorCallback;
                script.onerror = errorCallback
            }
            document.getElementsByTagName("HEAD")[0].appendChild(script);
            return script
        };
        Loader.LoadWURFL = function() {
            var wurflURL = location.protocol + "//device.pragmaticplay.net/wurfl.js";
            if (location.hostname.indexOf("ppgames.net") != -1) wurflURL = location.protocol + "//device.ppgames.net/wurfl.js";
            Loader.LoadScript(wurflURL, Loader.WURFLLoadHandler, Loader.WURFLErrorHandler);
            setTimeout(Loader.WURFLErrorHandler, 2E3)
        };
        Loader.WURFLLoadHandler = function() {
            if (Loader.WURFLProcessed) return;
            Loader.WURFLProcessed = true;
            var WURFL = window["WURFL"] || null;
            if (WURFL == null) {
                setTimeout(Loader.WURFLLoadHandler, 10);
                return
            }
            if (WURFL.complete_device_name != undefined)
                for (var id in LowEndDeviceIdentifiers)
                    if (WURFL.complete_device_name.indexOf(LowEndDeviceIdentifiers[id]) >= 0) {
                        UHT_LOW_END_DEVICE = true;
                        break
                    }
            console.log("WURFL loaded");
            UHT_DEVICE_TYPE = {
                MOBILE: WURFL.is_mobile,
                DESKTOP: !WURFL.is_mobile
            };
            Loader.SetExtraInfo();
            Loader.SendStatistics(JSON.stringify(WURFL))
        };
        Loader.WURFLErrorHandler = function() {
            if (Loader.WURFLProcessed) return;
            Loader.WURFLProcessed = true;
            console.log("WURFL not loaded use UAParser2");
            var device = UHT_UA_INFO.device;
            var mobile = device.type == "mobile" || device.type == "tablet";
            UHT_DEVICE_TYPE = {
                MOBILE: mobile,
                DESKTOP: !mobile
            };
            Loader.SetExtraInfo();
            Loader.SendStatistics(JSON.stringify({}))
        };
        Loader.SetExtraInfo = function() {
            var inFrame = false;
            try {
                inFrame = window.top != window
            } catch (e) {
                inFrame = true
            }
            UHT_FRAME = inFrame;
            var os = UHT_UA_INFO.os.name;
            var device = UHT_UA_INFO.device.model;
            if (device != undefined)
                for (var id in LowEndDeviceIdentifiers)
                    if (device.indexOf(LowEndDeviceIdentifiers[id]) >= 0) {
                        UHT_LOW_END_DEVICE = true;
                        break
                    }
            var classNames = [document.documentElement.className || "", os, device, String(UHT_UA_INFO.browser.name).replace(/\s/g, ""), UHT_CONFIG.MINI_MODE ? "MiniMode" : "StandardMode"];
            classNames.push(inFrame ?
                "InFrame" : "MainWindow");
            document.documentElement.className = classNames.join(" ");
            document.documentElement.id = UHT_DEVICE_TYPE.MOBILE ? "Mobile" : "Desktop"
        };
        var PLATFORM_APPENDED = false;
        Loader.LoadGame = function() {
            if (!Loader.WURFLProcessed) {
                setTimeout(Loader.LoadGame, 50);
                return
            }
            if (UHT_ALL && !PLATFORM_APPENDED) {
                UHT_CONFIG.GAME_URL += (UHT_CONFIG.MINI_MODE ? "mini" : UHT_DEVICE_TYPE.MOBILE ? "mobile" : "desktop") + "/";
                UHT_CONFIG.GAME_URL_ALTERNATIVE += (UHT_CONFIG.MINI_MODE ? "mini" : UHT_DEVICE_TYPE.MOBILE ? "mobile" : "desktop") + "/";
                PLATFORM_APPENDED = true
            }
            var script = Loader.LoadScript(UHT_CONFIG.GAME_URL + "bootstrap.js" + "?key=" + "d9bcf", Loader.LoadGameCallback, function() {
                document.getElementsByTagName("HEAD")[0].removeChild(script);
                currentDatapathRetries++;
                if (currentDatapathRetries == retriesBeforeAlternativeDatapath) {
                    UHT_CONFIG.GAME_URL = UHT_CONFIG.GAME_URL_ALTERNATIVE;
                    window["ga"]("LoadingTracker.send", "event", "uht_loading", "_USED_ALTERNATIVE_DATA_PATH", window["URLGameSymbol"], 1)
                }
                setTimeout(Loader.LoadGame, 250)
            })
        };
        Loader.LoadGameCallback = function() {
            delete window.Loader;
            window.onload(null)
        };
        Loader.Listener = function(json) {
            console.info("Loader::Receive " + json);
            var params = JSON.parse(json);
            if (params["common"] == "EVT_GET_CONFIGURATION") {
                delete window.sendToGame;
                var args = params["args"];
                if (typeof args["config"] == "string") args["config"] = JSON.parse(args["config"]);
                UHT_CONFIG.GAME_URL = args["config"]["datapath"];
                UHT_CONFIG.GAME_URL_ALTERNATIVE = args["config"]["datapath_alternative"];
                if (UHT_CONFIG.GAME_URL_ALTERNATIVE == undefined) UHT_CONFIG.GAME_URL_ALTERNATIVE = args["config"]["datapath"];
                UHT_CONFIG.STYLENAME =
                    args["config"]["styleName"];
                UHT_CONFIG.LANGUAGE = args["config"]["lang"];
                var tmp = UHT_CONFIG.GAME_URL.split("/");
                var pathParts = [];
                for (var i = 0; i < tmp.length; ++i)
                    if (tmp[i].length > 0) pathParts.push(tmp[i]);
                var symbol = pathParts[pathParts.length - 1];
                UHT_CONFIG.SYMBOL = symbol;
                UHT_CONFIG.MINI_MODE = args["config"]["minimode"] == "1";
                UHT_CONFIG.LOBBY_LAUNCHED = args["config"]["lobbyLaunched"] == true;
                if (args["config"]["brandRequirements"] != null && args["config"]["brandRequirements"].indexOf("FORCEMOBILE") != -1) {
                    UHT_DEVICE_TYPE.MOBILE =
                        true;
                    UHT_DEVICE_TYPE.DESKTOP = false;
                    UHT_CONFIG.MINI_MODE = false
                }
                var statURL = args["config"]["statisticsURL"];
                if (statURL != undefined) {
                    Loader.statisticsURL = statURL + (/\?/.test(statURL) ? "&" : "?") + "mgckey=" + args["config"]["mgckey"];
                    if (Loader.statistics != null) Loader.SendStatistics(Loader.statistics)
                }
                Loader.LoadGame();
                UHTLogotype.LoadLogoInfo(args["config"]["styleName"])
            }
        };
        var GA_timer_load_start = (new Date).getTime();
        Loader.Start = function() {
            UHTConsole.AllowToWrite(false);
            var sendToAdapter = null;
            try {
                sendToAdapter = window.parent["sendToAdapter"] || null
            } catch (e) {}
            if (sendToAdapter == null) sendToAdapter = window["sendToAdapter"] || null;
            var online = sendToAdapter != null;
            console.info("Loader::loaded - online = " + String(online));
            if (online) {
                window.sendToGame = Loader.Listener;
                sendToAdapter(JSON.stringify({
                    common: "EVT_GET_CONFIGURATION",
                    type: "html5"
                }))
            } else Loader.LoadGame()
        };
        Loader.SendStatistics = function(params) {
            if (Loader.statisticsURL == null) {
                Loader.statistics = params;
                return
            }
            var xhr = new XMLHttpRequest;
            xhr.open("POST", Loader.statisticsURL + "&channel=" + (UHT_CONFIG.MINI_MODE ? "mini" : "") + (UHT_DEVICE_TYPE.MOBILE ? "mobile" : "desktop") + (UHT_CONFIG.LOBBY_LAUNCHED ? "_mini_lobby" : ""), true);
            xhr.setRequestHeader("Content-type", "application/json");
            xhr.send(params)
        };
        if (location.href.indexOf("WURFL_NOT_ALLOWED") > -1) Loader.WURFLErrorHandler();
        else setTimeout(Loader.LoadWURFL, 0);
        window.onload = Loader.Start;
        var UHTLogoIsVisible = true;
        var UHTLogotype = {};
        UHTLogotype.name = null;
        UHTLogotype.path = null;
        UHTLogotype.data = null;
        UHTLogotype.logoEl = null;
        UHTLogotype.logoImg = null;
        UHTLogotype.timer = -1;
        UHTLogotype.duration = 2E3;
        UHTLogotype.gameLoadingStarted = false;
        UHTLogotype.hideLogoTimeout = null;
        UHTLogotype.LoadLogoInfo = function(name) {
            if (UHT_CONFIG.GAME_URL.length == 0 || UHTLogotype == null) return;
            var split = UHT_CONFIG.GAME_URL.split("/");
            split.splice(split.indexOf(UHT_CONFIG.SYMBOL) - 2);
            UHTLogotype.name = name;
            UHTLogotype.path = split.join("/") + "/operator_logos/";
            var script = Loader.LoadScript(UHTLogotype.path + "logo_info.js", UHTLogotype.OnLogoInfoLoaded, function() {
                document.getElementsByTagName("HEAD")[0].removeChild(script);
                currentDatapathRetries++;
                if (currentDatapathRetries == retriesBeforeAlternativeDatapath) {
                    UHT_CONFIG.GAME_URL =
                        UHT_CONFIG.GAME_URL_ALTERNATIVE;
                    PLATFORM_APPENDED = false
                }
                setTimeout(UHTLogotype.LoadLogoInfo.bind(null, UHT_CONFIG.STYLENAME), 250)
            })
        };
        UHTLogotype.OnLogoInfoLoaded = function() {
            if (UHTLogotype == null) return;
            var info = window["UHTLogotypeInfo"] || null;
            if (info != null) UHTLogotype.data = info[UHTLogotype.name] || null;
            if (UHTLogotype.data != null) {
                UHTLogotype.logoImg = new Image;
                UHTLogotype.logoImg.onload = UHTLogotype.OnLogoLoaded;
                UHTLogotype.logoImg.src = UHTLogotype.path + UHTLogotype.data["src"]
            } else {
                UHTLogotype.UpdateStyle("logoOff", "logoOn");
                UHTLogoIsVisible = false
            }
        };
        UHTLogotype.OnLogoLoaded = function() {
            var wheel = document.createElement("div");
            wheel.className = "logotype-wheel";
            var el = document.createElement("div");
            el.className = "logotype";
            el.style.backgroundColor = UHTLogotype.data["bg"];
            el.style.backgroundImage = "url('" + UHTLogotype.logoImg.src + "')";
            el.appendChild(wheel);
            document.body.appendChild(el);
            UHTLogotype.logoEl = el;
            UHTLogotype.UpdateStyle("logoOn", "logoOff");
            UHTLogotype.timer = (new Date).getTime();
            UHTLogoIsVisible = true;
            UHTLogotype.HandleResize();
            window.addEventListener("resize",
                UHTLogotype.HandleResize, false);
            if (UHTLogotype.gameLoadingStarted) UHTLogotype.DelayHideLogo(UHTLogotype.duration)
        };
        UHTLogotype.HandleResize = function() {
            if (UHTLogotype.data == null) return;
            var w = UHTLogotype.logoImg.width;
            var h = UHTLogotype.logoImg.height;
            var sw = "auto";
            var sh = "auto";
            var r1 = window.innerWidth / window.innerHeight;
            var r2 = w / h;
            if (UHTLogotype.data["fit"] == "shrink")
                if (r2 < r1) sh = "100%";
                else sw = "100%";
            else if (r2 < r1) sw = "100%";
            else sh = "100%";
            UHTLogotype.logoEl.style.backgroundSize = [sw, sh].join(" ")
        };
        UHTLogotype.GameLoadingStarted = function() {
            UHTLogotype.gameLoadingStarted = true;
            if (UHTLogotype.data == null) {
                UHTLogotype.HideLogo();
                return
            }
            if (UHTLogotype.timer > 0) {
                var dt = UHTLogotype.duration - ((new Date).getTime() - UHTLogotype.timer);
                if (dt <= 0) UHTLogotype.HideLogo();
                else UHTLogotype.DelayHideLogo(dt)
            }
        };
        UHTLogotype.DelayHideLogo = function(delay) {
            if (UHTLogotype.hideLogoTimeout != null) clearTimeout(UHTLogotype.hideLogoTimeout);
            UHTLogotype.hideLogoTimeout = setTimeout(UHTLogotype.HideLogo, delay)
        };
        UHTLogotype.HideLogo = function() {
            if (UHTLogotype.logoEl != null) {
                document.body.removeChild(UHTLogotype.logoEl);
                window.removeEventListener("resize", UHTLogotype.HandleResize, false)
            }
            UHTLogotype.UpdateStyle("logoOff", "logoOn");
            UHTLogotype = null;
            UHTLogoIsVisible = false
        };
        UHTLogotype.UpdateStyle = function(add, remove) {
            var split = (document.documentElement.className || "").split(" ");
            var cls = [];
            for (var i = 0; i < split.length; ++i)
                if (split[i].length > 0 && split[i] != remove) cls.push(split[i]);
            cls.push(add);
            document.documentElement.className = cls.join(" ")
        };
        UHT_ALL = true;
    </script>
    <script type="text/javascript" src="https:// askmebet-sg1.ppgames.net/gs2c/common/js/html5-script-external.js"></script>
    <script type="text/javascript">
        Html5GameManager.init({
            contextPath: "/gs2c",
            cashierUrl: "",
            lobbyUrl: "http://redirect.com",
            mobileCashierUrl: "",
            mobileLobbyUrl: "",
            gameConfig: '{"jurisdiction":"99","openHistoryInWindow":false,"RELOAD_JACKPOT":"/gs2c/jackpot/reload.do","styleName":"amb_viewbet","SETTINGS":"/gs2c/saveSettings.do","openHistoryInTab":true,"replaySystemUrl":"https://replay.pragmaticplay.net","integrationType":"HTTP","environmentId":"57","historyType":"internal","vendor":"T","currency":"THB","lang":"en","datapath":"https://askmebet-sg1.ppgames.net/gs2c/common/games-html5/games/vs/vs20cleocatra/","amountType":"COIN","LOGOUT":"/gs2c/logout.do","REGULATION":"https://askmebet-sg1.ppgames.net/gs2c/regulation/process.do?symbol\u003dvs20cleocatra","replaySystemContextPath":"/ReplayService","sessionKey":["c8ZRruZkj8YYbiVlUAIwYfohs0AWyHpwKfl0qvfhNG5TJtzsDLhinTAZ8VBuN7/nbW+sxOSGAJ5jumlx9/Fhng\u003d\u003d","SyYw6JcbL3e8X4WOkv/neg\u003d\u003d","L6SkGr4B8AZGQlMPyAh17QHat3lpLz/77/u19h9bGkySN1PeSLhqqIxnKTmfFO2mu8h1gYBtoU1jpwRtb4Z8VImABcT7Zqx65jX+VFMGTgyVOqe0ArOEQlRA8ffPonhBtsWWY7Lmsx6U4GUuwspAMWkjYN9bq355Spmk8FJ2x/vnq2DFqHZM9GzOzQCSisDzKn1aunrbB0JIDzbWrqBnT9DNBf2XvPmGzL+99CriKqUxLUHLxykGstnMUYP3Ktzd"],"showRealCash":"1","statisticsURL":"https://askmebet-sg1.ppgames.net/gs2c/stats.do","accountType":"R","clock":"0","mgckey":"AUTHTOKEN@9064272297135ced354bb52ddff2cf12797d4374b2dd4614ef4c2e9322fdd322~stylename@amb_viewbet~SESSION@5420b061-c9ba-4255-b815-7144a8d0d069~SN@807e2c4b","gameService":"https://askmebet-sg1.ppgames.net/gs2c/ge/v4/gameService","RELOAD_BALANCE":"/gs2c/reloadBalance.do","currencyOriginal":"THB","extend_events":"1","sessionTimeout":"30","CLOSE_GAME":"/gs2c/closeGame.do?symbol\u003dvs20cleocatra","region":"Asia","HISTORY":"https://askmebet-sg1.ppgames.net/gs2c/lastGameHistory.do?symbol\u003dvs20cleocatra\u0026mgckey\u003dAUTHTOKEN@9064272297135ced354bb52ddff2cf12797d4374b2dd4614ef4c2e9322fdd322~stylename@amb_viewbet~SESSION@5420b061-c9ba-4255-b815-7144a8d0d069~SN@807e2c4b"}',
            mgckey: "AUTHTOKEN@9064272297135ced354bb52ddff2cf12797d4374b2dd4614ef4c2e9322fdd322~stylename@amb_viewbet~SESSION@5420b061-c9ba-4255-b815-7144a8d0d069~SN@807e2c4b",
            jurisdictionMsg: "",
            extendSessionUrl: "",
            extendSessionInterval: null
        });
    </script>
</head>

<body class="CLIENT EXTERNAL HTML5">
    <div class="pageOverlap"></div>
    <div class="message-box browser-unsupported-message">
        <div class="message-title" style="color: #fff;">You are using an unsupported browser.</div>
        <div class="message-text" style="color: #fff;">Please use Google Chrome.</div>
    </div>

    <div id="wheelofpatience"></div>
    <div class="scale-holder" id="PauseRoot">
        <div class="scale-root" id="ScaleRoot">
            <div id="pauseindicator">
                <div class="pause-content">
                    <div class="pause-wheel"></div>
                    <div id="progressbar" class="progress-bar">
                        <div class="progress-value" id="progressvalue"></div>
                    </div>
                    <div id="DeferredLoadingText"></div>
                </div>
            </div>
        </div>
    </div>
    <script>
        setTimeout(function() {
            (function(i, s, o, g, r, a, m) {
                i['GoogleAnalyticsObject'] = r;
                i[r] = function() {
                    (i[r].q = i[r].q || []).push(arguments)
                }, i[r].l = 1 * new Date();
                a = s.createElement(o), a.async = 1;
                a.onload = function() {
                    var queue = [];
                    while (gaQueue.length > 0) {
                        var item = gaQueue.shift();
                        if (item.length > 0) {
                            if (item[0] == 'create')
                                ga.apply(i, item);
                            else
                                queue.push(item);
                        }
                    }
                    gaQueue = queue;
                    setTimeout(sendGAQueued, 1);
                };
                a.onerror = a.onabort = function() {
                    ga = function() {};
                    gaQueue = null
                };
                a.src = g;
                s.body.appendChild(a);
            })(window, document, 'script', '//www.googl e-analytics.com/analytics.js', 'ga');
        }, 1);
    </script>
</body>

</html>
```
