<?php
namespace Respins\BaseFunctions\Jobs;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Respins\BaseFunctions\Controllers\Data\GameContentsController;
class CasinoScraperJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private string $url;

    public function __construct(string $url)
    {
        $this->url = $url;
    }

    public function handle()
    {
        $data = $this->url;
        return GameContentsController::retrieve_demolink($data);
    }
}
