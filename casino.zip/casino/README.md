## Respins.io
Below is a bit of backstory, meant to explain (as best I can) in short this package's purpose, goal and back-story on how this method is actually used by the biggest casino operators, aggregators and game-studio's to offer games in illegal gambling areas and to skip big wins actively.

By using these methods at most the casino can be directly liable for loading in external scripts, with exception of providers like Pragmatic Play & Evolution Gaming (through proxy on Red Tiger Gaming) as they are actively jam-packing their games with basically "toggleable" scripts, thus still being able to get certified by simply changing the google analytics ID, it can be bridged with foul play games.

This package is a backend demonstration for KSA upon request but also to show gov's worldwide to open their eyes as new regulation is needed (prohibiting external loaded scripts on frontend of the casino games, so that providers and operators can be held directly liable on outside script execution). 

This package is made for to preview, while the methods used are so easy to employ that it's wonder it's not actively (mis-)used by cowboy operators or crypto scammers.

Regardless it's unfair compared to the legitimate casino's paying hefty for the games that at the same time sold for a diminished amount in another geo-region where gambling is illegal.

## The Respins.io Method Summarized
What we do is re-build the api endpoint on game content so we will receive the games and we will act as man in the middle - allowing us to change things like currency, skip spins, change outcome outright.

This package is focussing on the *backend* system & requirements. You can read in the "WHY.md" on reasoning why I can no longer build extensive systems & fit for production systems, however this package showcases working games that can be made relatively easy in-to full production state.

To protect legit providers from cowboy practices, what is not included is actual systems to disguise the API endpoints to make it seem like the games are being played legitimately. This you would need to create yourself, to somewhat retain the integrity of casino industry. 

However this is easily done with a little bit of craftsman work, after you have tested the backend on this package and are ready for production you can either release them as is (and use similarly looking domains) or you can pretty easy make some adaptions within the frontend gameclient so requests are looking to go to legit gameprovider URL's. In short (a picture says more as thousand word):

![Reroute example via Cloudfront/AWS Edge on BC.Game Real-money play](https://i.imgur.com/ngUUlEv.png)

Above you can see the response is actually not coming from pragmatic servers, but from the cloudfront edge AWS servers (which only god can know from external point of view who owns this), while the request still displays the pragmaticplay.com endpoint. This means that the operator/man in the middle can alter the game results and displays any they wish to do.


## Injecting malicious script to proxy legit game request
In short: you make the actual real game request either error (for example by purposely setup non existing game token), upon this error instead of displaying error to player (obviously) you have your frontend script to pick it up to your workers/endpoint or you straight pick it up by using AWS edge serverless services (cloudfront.net).

Many frontend solutions allow easy rewriting of urls upon triggers (like trigger being the game error), you can jam-pack it easily by using Zaraz/Workers KV on Cloudflare: check docs on Cloudflare products like Workers or other products to see the countless options you got to re-write/redirect the game request to your URL.

Using zaraz it becomes easy to load in dozens of scripts injections with iframe support (meaning that it will inject the zaraz script to iframes even from legitimate locations having nothing to do with you).

![Zaraz Cloudflare](https://i.imgur.com/pBKtrBl.png)

These 'malicious' game altering scripts can be loaded in via legitimate looking ways like google analytics).

For some examples of malicious .js scripts you can check OryxGaming demo page, 1x2Network Games (3PI: gameart, iron dog, relaxgaming, gamomat), Playtech, PragmaticPlay demo page (check the recaptcha payloads with google analytics malicious setup ready for use by the actual operators), BetConstruct, 1x2network (google on 'f1x2games' to find multiple malicious payload interfaces by 1x2gaming).

To view final stage results you can check casino's like BetCity.nl, Stake.com, Bc.game, Dama N.V. Casino's, Gammix, EveryMatrix, Reeve, ISoftBet. Please note that many of these companies are all owned by the same people, and in many cases they setup "aggregators" (softgamings.com, hub88.io, betconstruct, everymatrix, slotegrator etc) every 6-12 months before rising even any suspicion to not be personally liable but to also be untransparant. 

## Bit of background info on the illegal practices by "legitimate entertainment providers"
Please note that there are many game-providers & aggregators actively involved in this, so it is not only the operator side. 

Parties like OryxGaming, HollywoodTV, BlueOceanGaming, 1x2Network (3PI construction) (all in reality the same owner/party) offer the providers a full circuit scam where the profits within these illegal gambling activities are laundred professionally, in many case without any link to actual casino activities. 

Providers actively involved in scam are packing their demo games with bunch of malicious scripts so that the involved parties can easily adapt & change them, so the providers have the excuse to say "oops we made a mistake on our demo site", while in reality if you investigate them there is no way this is done non-maliciously when calling specific .js actions within games "respin" or "skip_spin" in conjuction with google analytics/sentry commands.

The operators are actively re-spinning/skipping big wins so profit is double for them.

Most likely over 90% of big game providers are involved in this, either unknowingly or putting blind eye while taking profits in pocket - as this method makes anyone able to take and exploit & commercialize any game that has a demo/fun-play function.

In some cases even for this purpose game providers bought by big parties (see red tiger, netent) and are setup for this cause, having extensive re-play functionality.

The relatively easy method describes and shows that games are loaded in without trace. To be used within illegal gambling areas like Syria, Iraq, China, USA etc. and most likely owners of these providers are taking profits to own pockets thus in addition to allowing skipped big win spins are massively defrauding their legitimate investors with these off-the-books games.

The games are then parallel made legit, by laundring through legit casino's like Betcity.nl and Dama N.V. network, so the profits & gains from the illegal gambling provisioning can flow back in-to throwaway aggregators like OryxGaming, Softgamings, Hub88 etc. which in turn can pay-out the aggregators in any way, shape or form.

You can read within personalstory.md what happened to me personally some of the liable people directly, like David G. Wainwright, Matteo, Dejan and more, in any case for official govs institutions it's as easy as: follow the money as you have the power to investigate actual money trails going outside and inside the country. 

## Example of Live Casino games being influenced
An example of a big U.K. scheme is to take David G. Wainwright, the HollywoodTV/Everymatrix owner (not on paper most likely, but factual and in reality owner - responsible for all illegal gambling live casino setups like TVBet.tv, Betgames.tv, Casinotv.info, CreedRunz etc.) and look in-to his vast laundry operation on jewelry and other easy-2-launder methods within U.K.

Contact me to review video proof of Spin2Wheels (roulette game) where is to view game landing on the number said in advance (back-stage) - this game is licensed by David G. Wainwright and is offered on all the said illegal gambling operations.

U.K. gambling commission can contact if needing additional info to steer towards right direction, all without any ask is available, though also involves personal information of David not fit for publication out of respect.

## Example of BetCity.nl laundry route
For example they will let big casino's as betcity.nl get a ton of 'provider costs', displaying tons of profit by adding fake losses to the books deposited by false 'big players' with dirty money, which in turn then have to be paid as provider cost by BetCity.nl to the aggregator/provider through parties like OryxGaming/BOG/1x2NETWORK). 

This will run through oryxgaming, while then in person or through other companies BetCity.nl casino management will be paid extra amounts from the illegal gambling sources which is deposited by these 'fake big players'. 

Badabingbadabom you got tons of crystal clear cash coming in back to the provider/aggregator from countries like Netherlands, U.K. etc. while in reality be it in Crypto Cash (see bc.game, stake.com etc.), Africa, Asia and other places players are actively duped by skipping their big win spins, from this most Dutch casino's are being funded, because of the reputation of the Netherlands within banking system this money is easily transferable world-wide to affiliates or others that need to get paid off.

Taking look at acquirement price/cost & also the big push behind BetCity.nl just showcases this single casino's laundry and how many players world-wide are being actively duped out of big win spins.

## Example of Red Tiger Gaming
Red Tiger's back office is interesting, as for some users (displayed below is login through BOG/Oryx details) there exist something called a VIP Lobby, which instead of the regular promotional material that is expected offers (and clearly boasts about it else not being named VIP Lobby) advanced ways to skip wins while keeping the player enticed by allowing "near-wins"/"close-big-wins".

![VIP Lobby Game displaying demogames with questionable options](https://i.imgur.com/qolSeuF.png)
The results can then be levied (raw game result) to the player, which will get ton of near-wins this way and spend much more before inevitable losing all.

Evolution Gaming (owner of Red Tiger Gaming, Netent also for those not aware) is notoriously known for illegal gambling activities after being penalized several occasion and recently even lost their investor's a bunch of money:
["Sweden's Evolution loses $3 bln of market value on illegal gaming accusation" - Reuters](https://www.reuters.com/technology/swedens-evolution-loses-3-bln-market-value-illegal-gaming-accusation-2021-11-17/)

You would think they would learn their lesson, but as it's their investor's who lost most of the money in above scandal and not management, instead they acquired Red Tiger to start exploiting games and skipping big wins in a way that also will never benefit back the investor's (games are off the books).

Anyone to investigate can also see the Netent.com's demo pages are jam-packed with altering scripts to allow same as Pragmatic Play the use of their games (through their owned parties like BOG/1x2Network etc. to get their games in illegal gambling areas).

Preload is done exact same way as in 1x2network, directly linking them all together as being the same driven/managed parties.

VIP Lobby game URL (similar to what 1x2network calls proLobby):
https://gserver-vip-lobby-external-dev.dopamine-gaming.com/vip-lobby-external/launcher/80sSpins?token=3d58dc5a69a058af33ba4409d1085fb5&playMode=real&lobbyURL=https://demo.redtiger.com&wheelWinOnly=false

Copy of contents on page itself (this is preload, so before the actual game is loaded in):
[Evolution Gaming's Red Tiger Game HTML](https://pastebin.com/1uMVYru8)

You can actively test this on psp-stage.softswiss.net where these "demo" games are loaded in (reasoning is obvious, why else implement a custom demo gaming list from "VIP" lobby).

Function preloaded, please note constant words as "bridge" and other words - as this basically is bridged to a "legitimate looking" session, making possible to relay any result wished:
```javascript
        (function () {
            'use strict';

            var params = com.casino.utils.getURLParams();
            var postParams = [];
            if (Object.keys(postParams).length > 0) {
                try {
                    window.sessionStorage.setItem('launcherPostParamsCache', JSON.stringify(postParams));
                } catch (e) {
                    // Just to be sure that we wont throw error if otherwise valid game launch will fail.
                }
            } else {
                try {
                    postParams = JSON.parse(window.sessionStorage.getItem('launcherPostParamsCache')) || {};
                } catch (e) {
                    // This is to make sure we don't throw error on empty session storage cache.
                    postParams = {};
                }
            }
            Object.keys(postParams).forEach(function (key){
                params[key] = postParams[key];
            });
            var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

            com.casino.preconfig = {
                bridge: {
					postParams: [],
                    feedUrl: 'https://feed-vip-lobby-external-dev.dopamine-gaming.com',
                    autoStart: false,
                    provider: params['provider'] || 'demoReal',
                    operator: params['provider'] || 'viplobby',
                    timestamp: '?t=1658835624',
                    notifications: {
                        inRealPlay: true,
                        inDemoPlay: true,
                        showUnfinishedWins: true,
                        showUnfinishedNoWins: true
                    },
                    bridgeLaunch: true
                },
                server: {
                    rgsApi: '/vip-lobby-external/platform/',
                    launchParams: {
                        gameId: '80sSpins'
                    }
                },
                game: {
                    namespace: 'com.nsg.game',
                    preconfig: {
                        cdn: 'https://cdn.dopamine-gaming.com/stable/games/slots-nsg/80sSpins/',
                        delayedBalanceUpdate: false,
                        defaultLang: 'en',
                        splash: true,
                        hideCurrency: isTrue('hideCurrency'),
                        disclaimer: '',
                        skin: params['skin'],
                        gameType: 'slot',
                        gameAppId: '80sSpins',
                        responsive: true,
                        addedAnticipation: params['addedAnticipation'] === 'false' ? false : true
                    }
                },
                bars: {
                    basePath: 'https://cdn.dopamine-gaming.com/stable/games/slots-nsg/80sSpins/../../bars-next/',
                    options: {
                        historySrc: 'https://cdn.dopamine-gaming.com/stable/games/slots-nsg/80sSpins/../../history/',
                        hasGamble: 'false' === 'true' && 'nsg' === 'cayetano' ? true : false
                    }
                },
                analytics: {
                    gaTrackingIds: ["UA-110132524-1"]
                }
            };

            com.casino.debug = {
                cdn: 'https://cdn.dopamine-gaming.com/stable/games/slots-nsg/80sSpins/',
                gameTools: false,
                advanced: false,
                replay: false,
                games: false,
                environment: false,
                params: {
                    currency: {
                        code:  params['currency'] ? params['currency'] : '',
                        symbol: params['symbol'] ? decodeURIComponent(params['symbol']) : '',
                    }
                }
            };

            com.casino.bridge.init(com.casino.preconfig);

            function isTrue(name) {
                return params[name] === 'true' || params[name] === '1';
            }

        })();
```

## Disclaimer
Be advised that I'm not a journalist, official or anyone to be taken serious - just a guy that got digitally shutdown by pretty much above parties (or it's dogs working for them) on my business and not allowing these crooks to use my aggregation for such practices, but more about that can be read elsewhere as all that is personal and really doesn't have anything to do with displaying & warning said govs.

Ofcourse having said that, nobody is angel within this industry as a common goal of everyone is to take as much profits as possible, while keeping the player come back. Though this is in another level and the fact also they are getting cocky enough to think they can make judgement on who's to 

You could call this a big fraud cartel - as said the people to go behind after initially the casino's is the aggregators, cause in the end they need white cash to flow back.

Also if a gov would be really interested in solving this problem long term, is few things but main thing is to try and create a secure frontend environment where the games are loaded in, without any external factors (google analytics, etc etc whatever) so you can directly make the game provider liable for foul play. 

To start off you can use this package and check the backend things within minutes, after proven it's not fairytale, you can then launch investigation and check exactly what frontend javascript is loaded in on games. Again the games itself will clear any certification requirements and so on, the scripts are loaded in later on casino-level through throwaway shell aggregators like Oryx Gaming and so on.

Main people behind this is Dejan Jovic (blueoceangaming.com / BOG / ORYXGAMING) && David G. Wainwright (EveryMatrix, Supercasino.com, Superbet, Gammix) - above that you will see the actual parties is going to point in direction of Evolution Gaming but they seem to have a brain and not directly make their own hands dirty. 

General rule of thumb is that Dejan/BOG will be in ownership of the bigger legit casino's (50+-~) like BetCity.nl and so on to launder profits & gains from Evo/1x2Network's casino's (1200+-).

Those interested need to look upon their own efforts for more - as there is so much more info that I can show/tell but it's just as warning signal to anyone that is legitimate that this is happening. I figured it would be better and upon request of KSA to make a working example of the backend handling and generation of the actual games to convert them to real-money games that can be influenced.




## Installation

You can install the package via composer:

```
composer require respins/base-functions
```

You can publish and run the migrations with:

```
php artisan vendor:publish --tag="base-functions-migrations"
php artisan migrate
```

You can publish the config file with:

```
php artisan vendor:publish --tag="base-functions-config"
```

# Respins.io base functions
Add to composer.json - change URL to path of this package:
```json 
    "repositories": [
	    {
		"type": "path",
		"url": "casino"
	    }
     ],
```

Add to require in composer.json:
```json
	"respins.io/casino": "*",
```

If you want to limit all outside URL's, include middleware (to either web, api or general requests) in App\Http\Kernel.php:
```php
  \Respins\BaseFunctions\Middleware\RespinsIPCheck::class,
```

## Standalone Mock PHP Script
Upload to external random host and use mockCallback() function on ```\Controllers\API\MockController\MockTransform()```. Make sure you make the script at minimum 755 chmod so it can write balance & log to .txt script.

```php
    header('Content-Type: application/json; charset=utf-8');

    /* Input Select */
    $win = $_GET["win"] ?? 'miss';
    $bet = $_GET["bet"] ?? 'miss';
    $action = $_GET["action"];

    $headers = array();
    foreach($_SERVER as $key => $value) {
     if (substr($key, 0, 5) <> 'HTTP_') {
        continue;
     }
     $headers[$key] = ($value);
    }
    $body = json_decode(file_get_contents('php://input'), true);
    $url = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER["REQUEST_URI"]; 
    $data_request = array('time' => time(), 'sent_headers' => $headers, 'sent_body' => $body, 'sent_url' => $url);

    /* .txt file containing the data */
    $balanceFile = 'balance.txt';
    $betLogFile = 'betLog.txt';
    $writeToLog = file_put_contents($betLogFile, json_encode($data_request)."\n", FILE_APPEND);   

    if(!$action) {
        $getBalance = file_get_contents($balanceFile);
        $responsePayload = array('status' => 'error', 'data' => array('message' => 'Missing action. Set get query to either: balance || betLog || game || reset_balance', 'data_request' => $data_request));
        echo json_encode($responsePayload);
        http_response_code(400); exit;
    }

    /* Reset Balance to 45000 (which should convert on aggregation side to using 100 coins, so 450$ = 45000) */
   if($action === 'reset_balance') {
        $resetToBalance = 45000;
        $writeNewBalance = file_put_contents($balanceFile, $resetToBalance); 
        $responsePayload = array('status' => 'success', 'data' => array('balance' => (int) 45000, 'message' => 'Reset balance to 45000 integer'), 'sent_request' => $data_request);
        echo json_encode($responsePayload);
        http_response_code(200); exit;
   }

    /* Retrieve betLog as JSON & link to the actual raw betLog */
   if($action === 'betLog') {
        $getLog = file_get_contents($betLogFile);
        $responsePayload = array('status' => 'success', 'data' => array('direct_url' => '/betLog.txt', 'log' => $getLog), 'sent_request' => $data_request);
        echo json_encode($responsePayload);
        http_response_code(200); exit;
   }

    /* Balance returning as integer (in cents) */
   if($action === 'balance') {
        $getBalance = file_get_contents($balanceFile);
        $responsePayload = array('status' => 'success', 'data' => array('balance' => (int) $getBalance, 'action' => $action), 'sent_request' => $data_request);
        echo json_encode($responsePayload);
        http_response_code(200); exit;
   }

   if($action === 'game') {
    if($win === 'miss') {
        $responsePayload = array('status' => 'error', 'data' => array('message' => 'Missing win in query parameters on game action.', 'data_request' => $data_request));
        echo json_encode($responsePayload);
        http_response_code(400); exit;
    }
    if($bet === 'miss') {
        $responsePayload = array('status' => 'error', 'data' => array('message' => 'Missing bet in query parameters on game action.', 'data_request' => $data_request));
        echo json_encode($responsePayload);
        http_response_code(400); exit;
    }

    $getBalance = file_get_contents($balanceFile);
    if($bet > $getBalance) {
        $responsePayload = array('status' => 'error', 'data' => array('message' => 'Not enough balance.', 'data_request' => $data_request));
        echo json_encode($responsePayload);
        http_response_code(400); exit;
    }
        
    /* Write balance changes to balance.txt and return */
    $newBalanceAfterGame = ($getBalance - $bet);
    $newBalanceAfterGame = ($newBalanceAfterGame + $win);
    $writeNewBalance = file_put_contents($balanceFile, $newBalanceAfterGame); 

    $responsePayload = array('status' => 'success', 'data' => array('balance' => (int) $newBalanceAfterGame, 'action' => $action), 'sent_request' => $data_request);
    echo json_encode($responsePayload);
    http_response_code(200); exit;
   }

    $responsePayload = array('status' => 'error', 'data' => array('message' => 'Action not found.', 'data_request' => $data_request));
    echo json_encode($responsePayload);
    http_response_code(400); exit;
```