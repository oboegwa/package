@extends('theme::layouts.app')
<script src="https://cdn.tailwindcss.com"></script>
